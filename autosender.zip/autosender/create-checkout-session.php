<?php

    // get database connection
include_once './app/config/core.php';
include_once './app/config/database.php';
include_once './app/config/model.php';
require_once './stripe-sdk/vendor/autoload.php';

echo '<PRE>';

//https://github.com/stripe-samples/accept-a-payment/blob/main/prebuilt-checkout-page/server/php/public/create-checkout-session.php

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

// This is your test secret API key.
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

//header('Content-Type: application/json');

$stripe = new \Stripe\StripeClient(STRIPE_SECRET_KEY);
$customer = $stripe->customers->create([
    'email' => 'sarangpatel23@gmail.com',
    'name' => 'Sarang Patel',
    //'description' => 'My First Test Customer (created for API docs)',

  ]);
$checkout_session = \Stripe\Checkout\Session::create([
    'line_items' => [
        ['price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'Plan name',
                    //'description' => 'description',
                    'images' => [
                        'https://assets.adidas.com/images/h_840,f_auto,q_auto:sensitive,fl_lossy,c_fill,g_auto/c678375652b24f36901bad8c011d2339_9366/Fassona_1.0_Shoes_Blue_EW2637_01_standard.jpg'
                    ]
                ],
                'unit_amount' => 2000,
            ],
            'quantity' => 1,
        ]
    ],
    
    'customer' => $customer->id,
    //'customer_email' => "sarangpatle@#gmai.com",
    'mode' => 'payment',
    'success_url' => SITE_URL. 'payment-success.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => SITE_URL . 'payment-cancel.php',
]);
//echo '<PRE>';
//print_r($checkout_session);
//echo $checkout_session->id;exit;

header("HTTP/1.1 303 See Other");
header("Location: " . $checkout_session->url);