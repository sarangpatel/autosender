<?php
include_once './config/core.php';
//print_r($_SESSION);exit;
if( !( isset($_SESSION['autosender']['user']) && ($_SESSION['autosender']['user']['id'] > 0) ) ){
    $_SESSION['autosender']['err_msg'] = 'Unauthorized';
   header('Location: ../login.php');
}

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

if( !$model->isSubscribed($_SESSION['autosender']['user']['id']) ) {
    header('Location: settings.php');
}



?>