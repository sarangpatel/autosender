<?php
include_once './config/core.php';
//print_r($_SESSION);exit;
if( !( isset($_SESSION['biolabrx']['user']) && ($_SESSION['biolabrx']['user']['id'] > 0) ) ){
//    $_SESSION['biolabrx']['err_msg'] = 'Unauthorized';
 //   header('Location: index.php');
}
?>