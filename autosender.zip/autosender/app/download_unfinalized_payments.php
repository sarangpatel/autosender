<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
include_once './security.php';


$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$start_date = $_POST['start_date'];
$end_date = $_POST['end_date'];
$data = $model->downloadUnfinalizedPayment($start_date,$end_date);
$csv = "";
if(count($data) > 0){
    $total_orders = count($data);
    $csv .= "\"Report For:\",\"HBT International LLC\"\n";
    $csv .=  "Stores:,\"Womens Hair Rescue Rx\"\n";
    $csv .=  "Start:,$start_date\n";
    $csv .=  "End:,$end_date\n";
    $csv .=  "\"Total No. Shipments:\",$total_orders\n";
    $csv .=  '"Order Date","Order Total",Store,"Order Number",Recipient,"Recipient Billing Address","Recipient Shipping Address","Email Address",Carrier,"Service Type","Destination Country","Destination Address Line 1","Destination Address Line 2","Destination City","Destination State/Province","Destination Postal Code","Destination Phone","Shipping Paid (by customer)","Total Shipping Cost",SKU,"Item Name"';
    $csv .= "\n"   ;
    foreach($data as $d){
        $orderDate = date('Y-m-d', strtotime($d['created_on']));
        $orderTotal = trim($d['total_amount']);
        $store =  trim($d['storename']);
        $orderNumber = "";
        $receipient = trim(addslashes($d['first_name']) . ' ' .  addslashes($d['last_name'])) ;
        $receipient_billing_address = trim(addslashes($d['address']));
        $receipient_shipping_address = trim(addslashes($d['address']));
        $email = trim($d['email']);
        $carrier = "";
        $service_type = "";
        $destination_country = trim($d['country_name']) ;
        $destination_address_line_1 =  trim($receipient_shipping_address);
        $destination_address_line_2 = "" ;
        $destination_city = trim($d['city']) ;
        $destination_state = trim($d['state']) ;
        $destination_postalcode = trim($d['pincode']) ;
        $destination_phone = trim($d['phone']) ;
        $shipping_paid = "" ;
        $total_shipping_cost = trim($d["shipping"]) ;
        $sku = trim($d["sku_id"]) ;
        $item_name = trim($d["product_name"]) ;
        $csv .= "$orderDate,$orderTotal,\"$store\",$orderNumber,\"$receipient\",\"$receipient_billing_address\",\"$receipient_shipping_address\",$email,$carrier";
        $csv .=  ",$service_type,\"$destination_country\",\"$destination_address_line_1\",\"$destination_address_line_2\",\"$destination_city\",\"$destination_state\"";
        $csv .=  ",\"$destination_postalcode\",\"$destination_phone\",$shipping_paid,$total_shipping_cost,$sku,\"$item_name\" ";
        $csv .= "\n";
    }
 }else{
     //$_SESSION['biolabrx']['err_msg'] = 'No data';
     header('Location: dashboard.php');
     exit;
 }
header("Content-type: text/csv");
header("Content-Disposition: attachment; filename=". $store . '_report-'.   date('YmdHis'). ".csv");
header("Pragma: no-cache");
header("Expires: 0");
echo $csv;

//echo '<PRE>';
//print_r($data);
?>