<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
include_once './security.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

$user_id = $_SESSION['autosender']['user']['id'];
$contacts = $model->getData('contacts', ' user_id = ? and  status = ? ', ' order by id desc, first_name asc limit 2000 ', [$user_id, 1] );
include_once './templates/outbox.php';
?> 