<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
include_once './security.php';
include_once './templates/dashboard.php';
?>