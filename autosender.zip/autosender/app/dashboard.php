<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
include_once './security.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];


$channels = $model->getData('channels', ' is_active = ? ', ' order by channel_name asc limit 500 ', [1]);
$templates = $model->getData('templates', ' user_id = ? and  is_active = ? ', ' order by id desc limit 500 ', [$user_id, 1] );
$tmp = array();
foreach($templates as $temp){
    $tmp[$temp['type']][] = $temp;
}
$templates = $tmp;
//print_r($tmp);
include_once './templates/dashboard.php';
?> 