<?php
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$login = $model->checkLogin($postData);
if(count($login) > 0){
    $_SESSION['autosender']['user'] = $login[0];
    header('Location: dashboard.php');
}else{
    $_SESSION['autosender']['err_msg'] = "Please enter correct Email / Password.";
    header('Location: ../login.php');
}

?>