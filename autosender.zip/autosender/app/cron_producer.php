<?php
ignore_user_abort(true);
set_time_limit(0);
include_once  dirname(__FILE__) . '/config/core.php';
include_once  dirname(__FILE__) . '/config/database.php';
include_once  dirname(__FILE__) . '/config/model.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

//DOORMAN
//https://github.com/silverstripe/doorman/blob/3/docs/en/getting-started.md

//12AM, 6 AM, 12PM, 6PM: every 6 hours

echo '<PRE>';
$now = date('Y-m-d H:i:s');
$total_messages = $model->countTotalMessagesToSend();
$total_messages = $total_messages['total'];
$start_index = 0;
$limit = 200; // per iteration / per process ( if need to spawn new process via exec ());
$contact_ids = array();

while($total_messages > 0){
    $total_messages = $total_messages - $limit;
    $contacts = $model->getContactToSend($start_index, $limit);
    foreach($contacts as $con){
        $next_send_at = date('Y-m-d H:i:s', strtotime($con['send_frequency']));
        $contact_ids[] = array($next_send_at, $con['id']);
    }
    $result = $model->insertIntoMessageQueue($contacts);
    $start_index = $start_index + $limit;
}
if(count($contact_ids)> 0){
    $model->updateContactWhichAreSent($contact_ids);
    echo 'Next send on <br />';
    print_r($contact_ids);
}else{
    echo 'No record to queue.';
}
?> 