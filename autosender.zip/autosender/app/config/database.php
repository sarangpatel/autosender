<?php
class Database{
  
    // specify your own database credentials
    /*private $host = "localhost";
    private $db_name = "hbt_products";
    private $username = "root";
    private $password = "root";*/

    private $host = "localhost";
    private $db_name = "hairjtpw_hbt_products";
    private $username = "hairjtpw_hbtuser";
    private $password = "iuhbLg3RJJRpdiJ";

    public $conn;


    
  
    // get the database connection
    public function getConnection(){
  
        $this->conn = null;
  
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
            exit;
        }
  
        return $this->conn;
    }
}
?>