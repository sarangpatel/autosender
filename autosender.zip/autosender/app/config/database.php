<?php
class Database{
  
    // specify your own database credentials
    
    // private $host = "localhost";
    // private $db_name = "autosender";
    // private $username = "root";
    // private $password = "root";
   
    
    private $host = "localhost";
    private $db_name = "novapro_testautosend";
    private $username = "novapro_novapro";
    private $password = "novapro@123";
   
    public $conn;


    
  
    // get the database connection
    public function getConnection(){
  
        $this->conn = null;
  
        try{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->exec("set names utf8");
        }catch(PDOException $exception){
            echo "Connection error: " . $exception->getMessage();
            exit;
        }
  
        return $this->conn;
    }
}
?>