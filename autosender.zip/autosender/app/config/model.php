<?php
class Model{
     private $conn;

     // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


	public function checkLogin($post){
		$email = trim($post["email"]);
		$password = md5(trim($post["password"]));

        $query = "SELECT * FROM users WHERE email = ? and password = ? and status = ? LIMIT 1";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$email,$password,1]);
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
			$data = $stmt->fetchAll();
        }
		return $data;
	}

	//table - 'users'
	//fields = a,b,c
	//data = ['sarang', 'patel']
	public function insertData($table, $fields, $data=[]){
		$fill = implode(',' , array_fill(0,count($data),'?'));
		$query = "insert into $table  ($fields) values ($fill)" ;
		$stmt = $this->conn->prepare($query);
		if (!$stmt) {
			$err_msg= $this->conn->errorInfo();
			return array('msg' => $err_msg[2], 'error' => true );
		}else{
			if($stmt->execute($data)){
				return array('msg' => 'success', 'data' =>  array('id' => $this->conn->lastInsertId()), 'error' => false );
			}else{
				// dump params now
				//print_R($stmt->debugDumpParams());

				$err_msg= $this->conn->errorInfo();
				return array('msg' => 'DB Error: Duplicate email or phone entered.', 'error' => true );
			}
		}
	}


	public function updateData($table, $qry = '', $values){
		$query = "UPDATE $table SET $qry ";
		$stmt = $this->conn->prepare($query);
		if($stmt->execute($values)){
			// dump params now
			//print_R($stmt->debugDumpParams());
			return array('msg' => 'success', 'error' => false );
		}else{
			// dump params now
			//print_R($stmt->debugDumpParams());

			return array('msg' => 'DB Error: Duplicate email or phone entered.', 'error' => true );
		}
	}

	public function deleteData($table, $qry = '', $values){
			//print_r($values);exit;
			$sql = 'DELETE FROM contacts
			WHERE id = :id';

			// prepare the statement for execution
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(':id', $values[0], PDO::PARAM_INT);
			if ($statement->execute()) {
				return array('msg' => 'success', 'error' => false );
			}else{
				return array('msg' => 'DB Error: Some error occured, please try again.', 'error' => true );

			}
		/* // execute the statement
		if ($statement->execute()) {

				$query = "DELETE from $table  where $qry ";
				$stmt = $this->conn->prepare($query);
				if($stmt->execute($values)){
					// dump params now
					//print_R($stmt->debugDumpParams());
					return array('msg' => 'success', 'error' => false );
				}else{
					// dump params now
					//print_R($stmt->debugDumpParams());

					return array('msg' => 'DB Error: Some error occured, please try again.', 'error' => true );
				}
		 */
	}



	public function getData($table, $whereStr = ' user_id = ? ', $order = ' order by id desc limit 500 ', $values){

        $query = "SELECT * FROM $table where $whereStr";
        $stmt = $this->conn->prepare($query);
        $stmt->execute($values);
		$data = $stmt->fetchAll();
		//print_R($stmt->debugDumpParams());
		return $data;
		
	}

		


}

?>