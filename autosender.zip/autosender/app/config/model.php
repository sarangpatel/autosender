<?php
class Model{
     private $conn;

     // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


	public function checkLogin($post){
		$email = trim($post["email"]);
		$password = md5(trim($post["password"]));

        $query = "SELECT * FROM users WHERE email = ? and password = ? and status = ? LIMIT 1";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$email,$password,1]);
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
			$data = $stmt->fetchAll();
        }
		return $data;
	}

	//table - 'users'
	//fields = a,b,c
	//data = ['sarang', 'patel']
	public function insertData($table, $fields, $data=[]){
		$fill = implode(',' , array_fill(0,count($data),'?'));
		$query = "insert into $table  ($fields) values ($fill)" ;
		$stmt = $this->conn->prepare($query);
		if (!$stmt) {
			$err_msg= $this->conn->errorInfo();
			return array('msg' => $err_msg[2], 'error' => true );
		}else{
			if($stmt->execute($data)){
				return array('msg' => 'success', 'data' =>  array('id' => $this->conn->lastInsertId()), 'error' => false );
				return;
			}else{
				// dump params now
				//print_R($stmt->debugDumpParams());

				$err_msg= $this->conn->errorInfo();
				return array('msg' => 'DB Error: Duplicate email or phone entered.', 'error' => true );
			}
		}
	}


	public function updateData($query){
		$stmt = $this->conn->prepare($query);
		$stmt->execute(array());
		// dump params now
		//print_R($stmt->debugDumpParams());
	}
	public function getData($table, $whereStr = ' user_id = ? ', $order = ' order by id desc limit 500 ', $values){

        $query = "SELECT * FROM $table where $whereStr";
        $stmt = $this->conn->prepare($query);
        $stmt->execute($values);
		$data = $stmt->fetchAll();
		//print_R($stmt->debugDumpParams());
		return $data;
		
	}

		


}

?>