<?php
class Model{
     private $conn;

     // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


	public function getUser($user_id){
        $query = "SELECT * FROM users WHERE id = ?  LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$user_id]);
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
			$data = $stmt->fetchAll();
			$query = "SELECT id, name, price, currency, max_contacts FROM plans where id = ?";
			// prepare query statement
			$stmt = $this->conn->prepare($query);
			$stmt->execute([$data[0]['plan_id']]);
			$plan = $stmt->fetch();
			$data[0]['plan'] = $plan;
		}
		return $data;
	}

	public function getTotalContacts($user_id){
		$query = "SELECT count(1) as total_contacts from contacts where user_id =  ? limit 1";
		// prepare query statement
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$user_id]);
		$total_contacts = $stmt->fetch();
		return $total_contacts['total_contacts'];
	}

	public function checkLogin($post){
		$email = trim($post["email"]);
		$password = md5(trim($post["password"]));

        $query = "SELECT * FROM users WHERE email = ? and password = ? and status = ? LIMIT 1";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        $stmt->execute([$email,$password,1]);
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
			$data = $stmt->fetchAll();
			$query = "SELECT id, name, price, max_contacts FROM plans where id = ?";
			// prepare query statement
			$stmt = $this->conn->prepare($query);
			$stmt->execute([$data[0]['plan_id']]);
			$plan = $stmt->fetch();
			$data[0]['plan'] = $plan;


        }
		return $data;
	}

	public function isEmailExists($email){
		$email = trim($email);
		$query = "SELECT count(1) as email_found from users where email = ? limit 1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$email]);
		$email_found = $stmt->fetch();
		if($email_found['email_found'] > 0){
			return true;
		}else{
			return false;
		}
	}

	public function isUserIdExists($user_id){
		$user_id = trim($user_id);
		$query = "SELECT count(1) as user_found from users where id = ? limit 1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$user_id]);
		$email_found = $stmt->fetch();
		if($email_found['user_found'] > 0){
			return true;
		}else{
			return false;
		}
	}


	

	public function getUserIdFromEmail($email){
		$email = trim($email);
		$query = "SELECT id from users where email = ? limit 1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$email]);
		$email_found = $stmt->fetch();
		if($email_found['id'] > 0){
			return $email_found['id'];
		}else{
			return 0;
		}
	}

	
	public function isSubscribed($user_id){
		//$email = trim($email);
		$curr_dt = date('Y-m-d H:i:s');
		$query = "SELECT count(1) as subscribed from users where id = ? AND payment_status  = ? AND (plan_valid_till IS NULL OR plan_valid_till <= ?) limit 1";
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$user_id, 'pending', $curr_dt]);
		$email_found = $stmt->fetch();
		if($email_found['subscribed'] > 0){
			return false;
		}else{
			return true;
		}
	}


	public function registerUser($post){
		$full_name = trim($post["full_name"]);
		$email = trim($post["email"]);
		$password = md5(trim($post["password"]));
		$plan_id = $post["plan_id"];
		if($plan_id == 1){
			$payment_status  = 'paid';
		}else{
			$payment_status  = 'pending';
		}

		$insertData = [$full_name, $email, $password, $plan_id, $payment_status, date('Y-m-d H:i:s')];
		return $this->insertData('users', 'full_name,email,password,plan_id,payment_status,created_on', $insertData );
	}




	//table - 'users'
	//fields = a,b,c
	//data = ['sarang', 'patel']
	public function insertData($table, $fields, $data=[]){
		$fill = implode(',' , array_fill(0,count($data),'?'));
		$query = "insert into $table  ($fields) values ($fill)" ;
		
		$stmt = $this->conn->prepare($query);
		if (!$stmt) {
			$err_msg= $this->conn->errorInfo();
			return array('msg' => $err_msg[2], 'error' => true );
		}else{
			if($stmt->execute($data)){
				return array('msg' => 'success', 'data' =>  array('id' => $this->conn->lastInsertId()), 'error' => false );
			}else{
				// dump params now
				//print_R($stmt->debugDumpParams());

				$err_msg= $this->conn->errorInfo();
				return array('msg' => 'DB Error: Duplicate email or phone entered.', 'error' => true );
			}
		}
	}

	public function insertIntoMessageQueue($data){
		$values = array(); 
		foreach($data as $row ) {
			$meta = json_encode(array('first_name' => $row['first_name'],  'last_name' => $row['last_name'], 'reply_to' => $row['sender_email']));
			$now = date('Y-m-d H:i:s');
			$values[] = "( '{$row['user_id']}', '{$row['id']}', '{$row['send_via']}', '{$row['email']}', {$row['template_id']}, '$meta' , '$now', '$now' )";
		}
		$query = "insert into message_queue (user_id,contact_id, send_via, send_to, template_id, meta, created_on,updated_on) values "  . implode(',', $values) ;
		$stmt = $this->conn->prepare($query);
		//print_R($stmt->debugDumpParams());

		if($stmt->execute([])){
			return true;;
		}else{
			return false;
		}
	}

	public function getContactToSend($start_index, $limit){
		$now = date('Y-m-d H:i:s');
/*         $query = "SELECT  c.id, u.email as sender_email, c.first_name, c.last_name, c.email, c.send_frequency, LOWER(TRIM(ch.channel_name)) as send_via, c.email, c.template_id from contacts c inner join users u ON u.id = c.user_id inner join user_channels uc on uc.contact_id = c.id 
		inner join channels ch on ch.id = uc.channel_id  WHERE c.scheduled_at <= ? and (c.end_date is NULL OR c.end_date >= ?) and " . 
				" c.status = ? order by id asc limit  " . $start_index .  ',' .  $limit;
 */

		$query = "SELECT  c.id, c.user_id,  u.email as sender_email, c.first_name, c.last_name, c.email, c.send_frequency, LOWER(TRIM(ch.channel_name)) as send_via, c.email, c.template_id from contacts c inner join users u ON u.id = c.user_id inner join user_channels uc on uc.contact_id = c.id 
		inner join channels ch on ch.id = uc.channel_id  WHERE c.scheduled_at <= ? and (c.end_date is NULL OR c.end_date >= ?) and " . 
				" c.status = ? AND (u.payment_status = 'paid' AND ( u.plan_valid_till IS NULL OR u.plan_valid_till >=  '$now' )) order by id asc limit  " . $start_index .  ',' .  $limit;


        $stmt = $this->conn->prepare($query);
        $stmt->execute([$now, $now, 1]);
		//print_R($stmt->debugDumpParams());exit;
		return $stmt->fetchAll();
	}

	public function updateContactWhichAreSent($contact_ids){
		foreach($contact_ids as $con){
			$now = date('Y-m-d H:i:s');
		    //$query = "UPDATE contacts set start_date = '{$con[0]}', last_sent_on = '$now'  where id = {$con[1]} ";
		    $query = "UPDATE contacts set scheduled_at = '{$con[0]}', last_sent_on = '$now'  where id = {$con[1]} ";

			$stmt = $this->conn->prepare($query);
			$stmt->execute([]);

		}
	}



	public function updatePassword($user_id, $password){
		$user_id = trim($user_id);
		$password = md5($password);
		$query = "UPDATE  users set password = ?  where id = ? LIMIT 1; ";
		$stmt = $this->conn->prepare($query);
		$stmt->execute([$password, $user_id]);
	}

	

	

	public function countTotalMessagesToSend(){
		$now = date('Y-m-d H:i:s');
        /*$query = "SELECT count(1) as total FROM contacts c inner join user_channels uc on uc.contact_id = c.id 
		inner join channels ch on ch.id = uc.channel_id   WHERE c.start_date <= ? and (c.end_date is NULL OR c.end_date >= ?) 
	     and c.status = ? order by c.id asc ";*/

		 $query = "SELECT count(1) as total from contacts c inner join users u ON u.id = c.user_id inner join user_channels uc on uc.contact_id = c.id 
		 inner join channels ch on ch.id = uc.channel_id  WHERE c.scheduled_at <= ? and (c.end_date is NULL OR c.end_date >= ?) and " . 
				 " c.status = ? AND (u.payment_status = 'paid' AND ( u.plan_valid_till IS NULL OR u.plan_valid_till >=  '$now' )) order by c.id asc";
 
         $stmt = $this->conn->prepare($query);
         $stmt->execute([$now, $now, 1]);
		//print_R($stmt->debugDumpParams());
		//exit;
        return $stmt->fetch();

	}



	public function updateData($table, $qry = '', $values){
		$query = "UPDATE $table SET $qry ";
		$stmt = $this->conn->prepare($query);
		if($stmt->execute($values)){
			// dump params now
			//print_R($stmt->debugDumpParams());
			return array('msg' => 'success', 'error' => false );
		}else{
			// dump params now
			//print_R($stmt->debugDumpParams());

			return array('msg' => 'DB Error: Duplicate email or phone entered.', 'error' => true );
		}
	}

	public function deleteData($table, $qry = '', $values){
			//print_r($values);exit;
			$sql = 'DELETE FROM ' . $table . '	WHERE id = :id';

			// prepare the statement for execution
			$statement = $this->conn->prepare($sql);
			$statement->bindParam(':id', $values[0], PDO::PARAM_INT);
			if ($statement->execute()) {
				return array('msg' => 'success', 'error' => false );
			}else{
				return array('msg' => 'DB Error: Some error occured, please try again.', 'error' => true );

			}
		/* // execute the statement
		if ($statement->execute()) {

				$query = "DELETE from $table  where $qry ";
				$stmt = $this->conn->prepare($query);
				if($stmt->execute($values)){
					// dump params now
					//print_R($stmt->debugDumpParams());
					return array('msg' => 'success', 'error' => false );
				}else{
					// dump params now
					//print_R($stmt->debugDumpParams());

					return array('msg' => 'DB Error: Some error occured, please try again.', 'error' => true );
				}
		 */
	}



	public function getData($table, $whereStr = ' user_id = ? ', $order = ' order by id desc limit 500 ', $values){

        $query = "SELECT * FROM $table where $whereStr $order";
        $stmt = $this->conn->prepare($query);
        $stmt->execute($values);
		$data = $stmt->fetchAll();
		return $data;
		
	}

		


}

?>