<?php
class Model{
     private $conn;

     // constructor with $db as database connection
    public function __construct($db){
        $this->conn = $db;
    }


	public function checkLogin($post){
		$email = trim($post["email"]);
		$password = md5(trim($post["password"]));

        $query = "SELECT * FROM users WHERE email ='$email' and password = '$password' and status = 1 LIMIT 1";
        // prepare query statement
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $num = $stmt->rowCount();
        $data = array();
        if($num > 0){
			$data = $stmt->fetchAll();
        }
		return $data;
	}

		public function insertData($table, $postData){
			$page = $postData["page"];
			$country_name = $postData["country_name"];
			$first_name = $postData["first_name"];
			$last_name = $postData["last_name"];
			$email = $postData["email"];
			$address = $postData["address"];
			$city = $postData["city"];
			$state = $postData["state"];
			$pincode = $postData["pincode"];
			$phone = $postData["phone"];
	
			$query = "insert into $table  (page, country_name, first_name, last_name, email, address, city,
					state, pincode, phone) values (?,?,?,?,?,?,?,?,?,?)" ;
			$stmt = $this->conn->prepare($query);
			$stmt->execute([$page,$country_name,$first_name,$last_name,$email,$address,$city,$state,$pincode,$phone]);
			// dump params now
			//print_R($stmt->debugDumpParams());
			return array();
		}

		public function addOrder($table, $postData){
			$order_id = $postData["order_id"];
			$customer_name = $postData["customer_name"];
			$email = $postData["email"];
			$amount = $postData["amount"];
			$currency_code = $postData["currency"];
			$shipping_address = $postData["shipping_address"];

			$payer_id = $postData["payer_id"];
			$status = $postData["status"];
			$paypal_response = $postData["paypal_response"];

			$query = "insert into $table  (order_id, customer_name, email,amount,currency,shipping_address, payer_id, status, paypal_response) values (?,?,?,?,?,?,?,?,?)" ;
			$stmt = $this->conn->prepare($query);
			$stmt->execute([$order_id,$customer_name,$email,$amount,$currency_code,$shipping_address,$payer_id,$status,$paypal_response]);
			// dump params now
			//print_R($stmt->debugDumpParams());
			return array();
		}

		public function downloadUnfinalizedPayment($start_date, $end_date){

			$query = "SELECT * FROM form_submissions WHERE  payment_status IS NULL and created_on between '$start_date 00:00:00' and '$end_date 23:59:59' order by id desc limit 500";
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$num = $stmt->rowCount();
			$data = array();
			if($num > 0){
				$data = $stmt->fetchAll();
			}
			return $data;
		}
		


}

?>