<?php
session_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);
  
date_default_timezone_set("UTC");
$PAGE_TITLE = 'AutoSender';  

const SITE_URL = 'http://localhost/autosender/';
const APP_SITE_URL = 'http://localhost/autosender/app/';

  // const SITE_URL = 'https://novaproduct.net/autosender/';
  // const APP_SITE_URL = 'https://novaproduct.net/autosender/app/';


const FROM_EMAIL = 'sarangpatel23@gmail.com';


function sendEmail($to,$subject,$content,$meta){
    $meta =     json_decode($meta,true);
    $headers  = "From: " . FROM_EMAIL . "\r\n";

    if(!empty($meta['reply_to']))
    $headers .= "Reply-To: " . $meta['reply_to'] . "\r\n";

	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion(). "\r\n";
	mail($to, $subject, $content, $headers);
}

?>