<?php
session_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);

  
date_default_timezone_set("UTC");
$PAGE_TITLE = 'Kesher Inc.';  


const STRIPE_SECRET_KEY = 'sk_test_51KAgztExAYOsmKBmoPk4JznufyZCpYTIsqYZKbCCENuIhFbUmg10A6KTK3rASHS6K4okIBpuTxcLvCaZaNR9n9wH00IVkXKOAG';
const STRIPE_PUB_KEY = 'pk_test_51KAgztExAYOsmKBmpO8iyKh6wqG9fswaW4vrJvA5xdpSX8YM3fmMPt7KIuPLAtkHnT1uzMxrwrxwvr9gUVxQ1slP00GJt5YsHS';

const SITE_URL = 'http://localhost/autosender/';
const APP_SITE_URL = 'http://localhost/autosender/app/';

//    const SITE_URL = 'https://novaproduct.net/autosender/';
//    const APP_SITE_URL = 'https://novaproduct.net/autosender/app/';


const FROM_EMAIL = 'sarangpatel23@gmail.com';

//print_R($_SESSION);exit;

function sendEmail($to,$subject,$content,$meta){
    $meta =     json_decode($meta,true);
    $headers  = "From: " . FROM_EMAIL . "\r\n";

    if(!empty($meta['reply_to']))
    $headers .= "Reply-To: " . $meta['reply_to'] . "\r\n";

	$headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion(). "\r\n";
	mail($to, $subject, $content, $headers);
}


function isSubscribed(){
  include_once 'model.php';

  $user_id = $_SESSION['autosender']['user']['id'];

}

//https://github.com/stripe-samples/accept-a-payment/blob/main/prebuilt-checkout-page/server/php/public/create-checkout-session.php

function getStripePaymentURL($user_id, $model){
    require_once '../stripe-sdk/vendor/autoload.php';
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
    $stripe = new \Stripe\StripeClient(STRIPE_SECRET_KEY);

    $userData = $model->getData('users',  ' id =  ? ' , ' order by id asc ' , [$user_id]);

    //$plan_id = (int)$userData[0]['plan_id'];
    $plan_id  = 2;
    $planData = $model->getData('plans',  ' id =  ? ' , ' order by id asc ' , [$plan_id]);
    $planData = $planData[0];

    if(empty($userData[0]['stripe_cus_id'])){
        $customer = $stripe->customers->create([
          'email' => $userData[0]['email'],
          'name' => $userData[0]['full_name']
        ]);
        $model->updateData('users', ' stripe_cus_id = ? where id = ? ',   [$customer->id, $user_id]);
        $stripe_cus_id = $customer->id;
    }else{
      $stripe_cus_id = $userData[0]['stripe_cus_id'];

    }

    $checkout_session = \Stripe\Checkout\Session::create([
        'line_items' => [
            ['price_data' => [
                    'currency' => $planData['currency'],
                    'product_data' => [
                        'name' => $planData['name'],
                        //'description' => 'description',
                        'images' => [
                            'https://assets.adidas.com/images/h_840,f_auto,q_auto:sensitive,fl_lossy,c_fill,g_auto/c678375652b24f36901bad8c011d2339_9366/Fassona_1.0_Shoes_Blue_EW2637_01_standard.jpg'
                        ]
                    ],
                    'unit_amount' => $planData['price']*100,
                ],
                'quantity' => 1,
            ]
        ],
        
        'customer' => $stripe_cus_id,
        //'customer_email' => "sarangpatle@#gmai.com",
        'mode' => 'payment',
        'success_url' => SITE_URL. 'payment-success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => SITE_URL . 'payment-cancel.php',
    ]);
    //echo '<PRE>';
    //print_r($checkout_session);
    //echo $checkout_session->id;exit;
    return  $checkout_session->url;
}


?>