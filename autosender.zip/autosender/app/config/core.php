<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);
  
date_default_timezone_set("UTC");
$PAGE_TITLE = 'AutoSender';  

const SITE_URL = 'http://localhost/autosender/';
const APP_SITE_URL = 'http://localhost/autosender/app/';

//  const SITE_URL = 'https://novaproduct.net/smartpages/members/';
//  const BASE_SITE_URL = 'https://novaproduct.net/smartpages/';

?>