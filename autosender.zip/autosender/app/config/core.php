<?php
session_start();
ini_set('display_errors', 0);
error_reporting(E_ALL);
  
// home page url
//$api_url="http://localhost/engwomenhair/";

?>