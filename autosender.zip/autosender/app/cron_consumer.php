<?php
ignore_user_abort(true);
set_time_limit(0);
include_once  dirname(__FILE__) . '/config/core.php';
include_once  dirname(__FILE__) . '/config/database.php';
include_once  dirname(__FILE__) . '/config/model.php';
$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

//SET EVERY 30 mins
//set 0 = pending, 1=sent (FUTURE: if want successful status for each sent, add status = 2 for successfully sent )
echo '<PRE>';

$limit = 500;
$query = "SELECT mq.*, t.subject, t.content from message_queue mq inner join templates t on t.id = mq.template_id  " .
            " where mq.sent = 0 order by mq.id asc limit $limit ";
$stmt = $db->prepare($query);
$stmt->execute([]);
$records = $stmt->fetchAll();
$updateValues = array();
foreach($records as $record){
    $updateValues[] = $record['id'];
}
$now = date('Y-m-d H:i:s');
//THIS will prevent other consumer to send duplicate messages as sent = 1
$query = "UPDATE message_queue set sent = 1, updated_on =  '$now' where id in ( " . implode(',', $updateValues) . " )";
$stmt = $db->prepare($query);
$stmt->execute([]);
//send email
foreach($records as $record){
    if(strtolower(trim($record['send_via'])) == 'email' ){
        echo $record['send_to']. '<br />';
        sendEmail($record['send_to'], $record['subject'], $record['content'], $record['meta']);
    }
}
if(count($records) == 0){
    echo 'No emails to sent.';
}


?> 