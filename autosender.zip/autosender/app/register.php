<?php
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$plan_id = (int)$postData['plan_id'];
/*if($plan_id !== 1){ 
    if($model->isEmailExists($postData['email'])){
        $_SESSION['autosender']['err_msg'] = "Email already exists. Please try another.";
        header('Location: ../register.php');
        exit;
    }else{

    }
}else{*/
    $register = $model->registerUser($postData);
    if( !$register['error']){
        $reg_user = $model->getUser($register['data']['id']);
        $_SESSION['autosender']['user'] = $reg_user[0];
        if($plan_id !== 1){ //not free plan, redirect for payment page, once payment succeeded update 'plan_valid_till' & payment_status = paid
            //header('Location: ../stripe-payment.php');
            $stripeCheckoutURl = getStripePaymentURL($register['data']['id'], $model);
            header("HTTP/1.1 303 See Other");
            header("Location: " . $stripeCheckoutURl);
        }else{
            header('Location: dashboard.php');
        }

    }else{
        $_SESSION['autosender']['err_msg'] = "Email already exists. Please try another.";
        header('Location: ../register.php');
    }
/*} */

?>