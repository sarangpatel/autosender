"use strict";
var MainApp;

$(document).ready(function () {
	MainApp = function () {

			//MainApp.isLogin()
			MainApp.prototype.isLogin = function () {
				let isLoggedIn = getCookie('isLoggedin');
				if (typeof isLoggedIn !== 'undefined' && isLoggedIn != '') {
					return true;
				} else {
					//window.location.href = globalSite + 'index.html';
					return false;
				}
			},
			MainApp.prototype.previewTemplate = function (content) {
				var left = (screen.width - 800) / 2;
				var top = (screen.height - 800) / 4;
				var win = window.open("", "Template - Preview", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes," + 
					" width=800,height=700,top="+top+",left="+left);
					win.document.body.innerHTML = content;
			},
			MainApp.prototype.signOut = function () {
				removeToken();
				console.log('signout successfully', "");
				window.location.href = "index.html";
			},
			MainApp.prototype.login = function (email, password) {
				return new Promise(function(resolve,reject){
					console.log('Login...');
					MainApp.promiseApiCall(METHOD_POST_LOGIN, 'POST', { email: email, password: password }).then(function (user) {
						console.log('INSIDE login:', user);
						setCookie('authToken', user.data[0]['token'], globalKeepLoggedIn); //30 days
						setCookie('isLoggedin', 1, globalKeepLoggedIn); //30 days
						setCookie('loggedInUser', JSON.stringify(user.data[0]), globalKeepLoggedIn);//30 days
						resolve('sucess');
						//window.location.href = appLandingPage;
					}).catch((error) => {
						console.log('Error:', error);
						reject(error);
						//swal ( "Oops" ,  error.message ,  "error" );
					});
				});
			},
			MainApp.prototype.initAjaxRequest = function () {
				$.ajaxSetup({
					beforeSend: function (xhr) {
						xhr.setRequestHeader('Authorization', getCookie('authToken'));
					}
				});
			},
			MainApp.prototype.getQueryParams = function (name) {
				name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
				var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
				var results = regex.exec(location.search);
				return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			},
			MainApp.prototype.promiseApiCall =function(method,method_type,data){
				return new Promise((resolve, reject) => {
					try{
						 MainApp.initAjaxRequest();
						 if(method_type == 'POST' || method_type == 'PUT'  ){
							  if(data){
								data = JSON.stringify(data);
							  }else{
								data = JSON.stringify({});
							  }
						 }
						  $.ajax({
								url : method,
								type: method_type,
								dataType: 'json',
								contentType: 'application/json',
								data: data
						  })
						  .done(function( data, textStatus, jQxhr ){
								console.log('ajaxsucess');
								if(data.code === 1) //SUCCESS
								resolve(data);
								else
								reject({ 'message' : 'ERROR: ' +   data.message, 'data' : data.data});
							})
						  .fail(function( jqXhr, textStatus, errorThrown ){
								//reject({ 'message' : 'API ERROR: ' +  JSON.stringify(jqXhr), 'data' : data.data});
								reject({ 'message' : 'ERROR: ' +  jqXhr.responseJSON.message, 'data' : jqXhr.responseJSON.data});
							});
					}catch(e){
						reject({ 'message' : 'ERROR(catch): ' +  e.message, 'data' : data.data});
					}
				});
			},
			MainApp.prototype.getCategories =  function(){
				return new Promise(function(resolve,reject){
					MainApp.promiseApiCall(METHOD_GETCATEGORIES,'GET',{},{}).then(function(data){
						console.log('Categories: Success');
						resolve(data.result.result);
					}).catch((error) => {
						console.log('Error:', error);
						resolve([]);
					});
				});
			},
			MainApp.prototype.getRowProperties = function(row){
				let estr='';
				for (const prop in row) {
					if(prop == 'content')continue;
					estr += ' data-' + prop + ' = "' + MainApp.htmlEntities(row[prop]) + '" ';
				}
				return estr;
			},
			MainApp.prototype.htmlEntities = function(str){
				return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
			},
			MainApp.prototype.loadDynamicTable = function(auth,tblId,url,cols,coldefs,colsorts,cb,paging){
				console.log('inside load dynamic table');
				try{
					 if(auth){
						MainApp.initAjaxRequest();
					}
					$('.overlay').show();

					let table = $(tblId).DataTable({
						 'lengthChange': true,
						 'paging'      : paging,
						 'lengthChange': true,
						 'searching'   : true,
						 'ordering'    : true,
						 /*'dom': 'Bfrtip',*/
						 /*'dom': 'Bfrtip',
						 'buttons': [
						 'copy', 'csv', 'excel', 'pdf', 'print'
						 ],*/
						 'initComplete': function () {
						  },
						'ajax' : {
						  'url' : url,
						  'dataSrc': function(json){
								$('.overlay').hide();
								if(parseInt(json.code) === 0){
									swal("Alert!", json.message, "error");
									return {};
								}
								if(json.data == null)return {}
								if(json.code === 1){
									return json.data;
								}else {
									swal("Alert!", json.message, "error");
									return {}
								}
						   },
						  'error': function( jqXhr, textStatus, errorThrown ){
							$('.overlay').hide();
							$(tblId).find('.dataTables_empty').html(textStatus.toUpperCase() +  ': Error getting data from Server.');
						  }
						},
						'columns': cols,
						select: true,
						colReorder: true,
						/*buttons: [
							{
								extend: 'collection',
								text: 'Export',
								buttons: [
									'excel'
								]
							}
						],*/
						'columnDefs': coldefs == null ? '' : coldefs,
						'order': colsorts == null ? [] : colsorts,
						'responsive': true
					  });
					 return table;
				}catch(e){
					// alert(e.message);
					swal("Alert!", e.message, "error");
					return table;
				}
			},
			MainApp.prototype.loadEditTemplate = function(frmId){
				console.log("loading edit template");
				let template_id = MainApp.getQueryParams('template_id');
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_GET_TEMPLATES + '/' + template_id,'GET',{}).then(function(data){
					$(frmId).find('input[name = "template_id"]').val(data.data[0].id);
					$(frmId).find('input[name = "template_name"]').val(data.data[0].name);
					$(frmId).find('input[name = "template_subject"]').val(data.data[0].subject);
					//$(frmId).find('textarea[name = "template_content"]').val(data.data[0].content);
					tinymce.init({
						selector: 'textarea#template_content',
						height: 500,
						menubar: false,
						plugins: [
							' lists link image charmap print preview anchor',
							'searchreplace visualblocks code fullscreen',
							'insertdatetime media table paste code help wordcount'
						],
						toolbar: 'undo redo | formatselect | ' +
						'bold italic backcolor | alignleft aligncenter ' +
						'alignright alignjustify | bullist numlist outdent indent | ' +
						'removeformat | code',
						content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:14px }',
						setup: function (editor) {
							editor.on('init', function (e) {
								editor.setContent(data.data[0].content);
							});
						}
					});
					$('.overlay').hide();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			},
			MainApp.prototype.loadEditList = function(frmId){
				console.log("loading edit list");
				let list_id = MainApp.getQueryParams('list_id');
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_GET_LISTS + '/' + list_id,'GET',{}).then(function(data){
					$(frmId).find('input[name = "list_id"]').val(data.data[0].id);
					$(frmId).find('input[name = "list_name"]').val(data.data[0].name);
					$('.overlay').hide();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			},
			MainApp.prototype.loadSendEmailPage = function(frmId){
				console.log("loading send email page.");
				//MainApp.initAjaxRequest();
				$('.overlay').show();

				MainApp.promiseApiCall(METHOD_GET_ADMIN_EMAILS + '/' + JSON.parse(getCookie('loggedInUser')).id,'GET',{}).then(function(data){
					$.each(data.data, function(index, value) {
					 	$(frmId).find('select[name="admin_email"]').append($('<option>').text(value.name + ' <' + value. email +  '>').attr('value', value.id));
					 });
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});

				$.getJSON(METHOD_GET_LISTS, function( data ) {
					$.each( data.data, function( index, value ) {
						$(frmId).find('select[name="contact_list"]').append($('<option>').text(value.name + ' (' + $.number(value. total_contacts) +  ')').attr('value', value.id));
					});
				});
				$.getJSON(METHOD_GET_TEMPLATES, function( data ) {
					$.each( data.data, function( index, value ) {
						$(frmId).find('select[name="template_name"]').append($('<option>').text(value.name).attr('value', value.id));
					});
				});
				$('.overlay').hide();



			},
			MainApp.prototype.loadTemplateTable = function(tblId){
				console.log("loading template table");
				let cols  =  [
					{ data: 'name' },
					{data: 'subject'},
					{ mRender: function (data, type, row) {
						return moment(row.created_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						return moment(row.updated_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						let attr = MainApp.getRowProperties(row);
						return '<a href="edit-template.html?template_id=' + row.id + '" class="btn btn-primary">Edit</a>' + 
							'&nbsp;<a href="#"' +  attr   + ' class="btn btn-primary delTemplate">Delete</a>';
						}
					}
				];
				let coldefs = [
					{ orderable: false, targets: -1 },
				];
				/*let colsorts = [[ 1, "desc" ]];*/
				let colsorts = null;
				return MainApp.loadDynamicTable(true,tblId, METHOD_GET_TEMPLATES,
						cols,coldefs,colsorts,'',true);
			},
			MainApp.prototype.loadCampaignTable = function(tblId){
				console.log("loading campaign table");
				let cols  =  [
					{data: 'campaign_name'},
					{ mRender: function (data, type, row) {
						return `${row.from_name} <br /> (${row.from_email})`; 
						}
					},
					/*{ data: 'bounce_email' },*/
					{data: 'total_emails'},
					{data: 'sent_emails'},
					{data: 'unsent_emails'},
					{data: 'compliants_emails'},
					{data: 'open_count'},
					{data: 'click_count'},
					{ mRender: function (data, type, row) {
						return moment(row.created_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						return moment(row.updated_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
							return row.status.toUpperCase(); 
						}
					},
					{ mRender: function (data, type, row) {
						let attr = MainApp.getRowProperties(row);
							if(row.status == 'pending'){
								return '<a href="#" ' +   attr   + ' class="campaign-link-mg btn btn-sm btn-primary approveCampaign">Approve</a>' + 
									'&nbsp; <a href="#" ' +   attr   + ' class="campaign-link-mg btn btn-sm  btn-danger cancelCampaign">Cancel</a>';
							}else if(row.status == 'processing') {
								return '';
								//return '<a href="#"' +  attr   + ' class="campaign-link-mg btn btn-sm btn-primary refreshSentMailCount">Get Sent Mail(s)</a>';
							}else if(row.status == 'completed') {
								return '<a href="#"' +  attr   + ' class="campaign-link-mg btn btn-sm btn-primary downloadReport">Download Report</a>';
							}else{
								return '';
							}
						}
					}
				];
				let coldefs = [
					{ orderable: false, targets: -1 },
				];
				/*let colsorts = [[ 1, "desc" ]];*/
				let colsorts = null;
				//event["queryStringParameters"]['queryparam1']
				return MainApp.loadDynamicTable(true, tblId, METHOD_GET_CAMPAIGNS+'?user_id=' + JSON.parse(getCookie('loggedInUser')).id,
						cols,coldefs,colsorts,'',true);
			},

			MainApp.prototype.loadListTable = function(tblId){
				console.log("loading list table");
				let cols  =  [
					{ data: 'name' },
					{data: 'total_contacts'},
					{ mRender: function (data, type, row) {
						return moment(row.created_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						return moment(row.updated_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						let attr = MainApp.getRowProperties(row);
						return '<a href="edit-contactlist.html?list_id=' + row.id + '" class="btn btn-primary">Edit</a>' + 
							'&nbsp;<a href="#"' +  attr   + ' class="btn btn-primary delList">Delete</a>&nbsp;<a href="#"' +  attr   + ' class="btn btn-primary showContact">Contacts</a>';
						}
					}
				];
				let coldefs = [
					{ orderable: false, targets: -1 },
				];
				/*let colsorts = [[ 1, "desc" ]];*/
				let colsorts = null;
				return MainApp.loadDynamicTable(true, tblId, METHOD_GET_LISTS,
						cols,coldefs,colsorts,'',true);
			},
			MainApp.prototype.loadContactTable = function(tblId,list_id){
				console.log("loading contact table");
				let cols  =  [
					{ mRender: function (data, type, row) {
						return row.contact_firstname + ' ' + row.contact_lastname; 
						}
					},
					{ data: 'contact_email' },

					{ mRender: function (data, type, row) {
						return moment(row.created_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						return moment(row.updated_on).format(globalDateTimeFormat); 
						}
					}
				];
				let coldefs = null
				/*let colsorts = [[ 1, "desc" ]];*/
				let colsorts = null;

				let table = $(tblId).DataTable({
					'lengthChange': true,
					'paging'      : true,
					'lengthChange': true,
					'searching'   : true,
					'error': function( jqXhr, textStatus, errorThrown ){
						$(tblId).find('.dataTables_empty').html(textStatus.toUpperCase() +  ': Error getting data from Server.');
					},
					"preDrawCallback": function( settings ) {
					}, 
					"drawCallback": function( settings ) {
						console.log('contact table loaded');
					},
					'columns': cols,
					select: true,
					colReorder: true,
					'columnDefs': coldefs == null ? '' : coldefs,
					'order': colsorts == null ? [] : colsorts,
					'responsive': true
				  });
				return table;
				//return MainApp.loadDynamicTable(true, tblId, METHOD_GET_CONTACTS + '/'  + list_id,
				//		cols,coldefs,colsorts,'',true);
			},
			MainApp.prototype.init = function () {
				return new Promise(function (resolve, reject) {
					resolve('app initialized');
				});
			}
		};
	MainApp = new MainApp;
	(function () {
		try {
			var initApp = MainApp.init();
			initApp.then(function (r) {
				console.log(r);
				if(MainApp.isLogin()){
					console.log('logged in');
					$('.header-welcome-msg').html('Welcome ' + JSON.parse(getCookie('loggedInUser')).full_name);
					if ($('#templateTable').length) {
						MainApp.loadTemplateTable('#templateTable');
					}
					if ($('#listTable').length) {
						MainApp.loadListTable('#listTable');
					}

					if($('#frmEditTemplate').length){
						MainApp.loadEditTemplate('#frmEditTemplate');
					}
					if($('#frmEditList').length){
						MainApp.loadEditList('#frmEditList');
					}
					if($('#frmSendTestEmail').length){
						MainApp.loadSendEmailPage('#frmSendTestEmail');
					}
					if ($('#sampleTable').length) {
						MainApp.loadCampaignTable('#sampleTable');
					}

					

				}else{
					let winloc = window.location.href;
					let page = winloc.substring(winloc.lastIndexOf("/"));
					console.log('page', page);
					if(!(page == '/' || page == '/index.html' || page == '' || (page.indexOf("/reset-password.html") !== -1) ))//if not login / home page
					window.location.href = 'index.html';

					if ($('#frmResetPassword').length) {
						let email = MainApp.getQueryParams('email');
						let token = MainApp.getQueryParams('token');
						let user_id = MainApp.getQueryParams('user_id');
						$('#frmResetPassword').find('input[name="email"]').val(email);
						$('#frmResetPassword').find('input[name="token"]').val(token);
						$('#frmResetPassword').find('input[name="user_id"]').val(user_id);
					}
				}
			});
		} catch (e) {
			console.log('error', e.message);
		}
	})();
	
	$('.app-header').on('click', '.signout', function (evt) {
		evt.preventDefault();
		MainApp.signOut();
	});

	$('main.app-content').on('click', '#templatePreviewBtnId', function (evt) {
		evt.preventDefault();
		console.log($(this).closest('form').attr('name'));
		let content = $(this).closest('form').find('textarea[name="template_content"]').val();
		if($.trim(content) == '')content = 'No content';
		MainApp.previewTemplate(content);
	});


	$('main.app-content').on('click', '#templateViewPlaceholderBtnId', function (evt) {
		evt.preventDefault();
		$('#template-placeholders').slideToggle('fast');
	});
	


	$("#frmNewTemplate,#frmEditTemplate").validate({
		rules:{
			"template_name":{
				required: true
			},
			"template_subject":{
				required: true
			},
			"template_content":{
				required: true
			}
		},
		messages: {
			"template_name":{
				required: "Please enter Template Name."
			},
			"template_subject":{
				required: "Please enter Template Subject."
			},
			"template_content":{
				required: "Please enter Template Content."
			}

		},

		/*errorPlacement: function (error, element) {
			if (element.attr("type") == "checkbox") {
				error.insertAfter($(element).parent().parent());
			} else {
				// something else
			}
		},*/

		submitHandler: function(form){
			console.log("formsubmitted");
			console.log($(form).attr('id'));
			let template_name  =  $(form).find("input[name='template_name']").val();
			let template_subject  =  $(form).find("input[name='template_subject']").val();
			//let template_content =  $(form).find("textarea[name='template_content']").val();
			let template_content =  tinymce.get("template_content").getContent();
			console.log(template_content);
			let apiURL = METHOD_CREATE_TEMPLATES;
			let apiMethod = 'POST';
			let succMsg = 'created';
			if($(form).attr('id') === 'frmEditTemplate' ){
				apiURL = METHOD_UPDATE_TEMPLATES + '/' + $(form).find("input[name='template_id']").val();
				apiMethod = 'PUT';
				succMsg = 'updated';
			}
			$('.overlay').show();
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );

			MainApp.promiseApiCall(apiURL,apiMethod,
				{ name: template_name, subject: template_subject, content: template_content}).then(function(data){
					console.log('CRUD template', data);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					$('.overlay').hide();
					swal('Success!', 'Template ' + succMsg + ' successfully.', "success");
				}).catch((error) => {
					console.log('Crate Template Error:', error);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			return false;
		}
	});

	$('#sampleTable').on('click', '.downloadReport', function (evt) {
		evt.preventDefault();
		let reportURL = $(this).data('report_path');
		window.location.href = reportURL;
		return false;
	});

	$('#sampleTable').on('click', '.refreshSentMailCount', function (evt) {
		evt.preventDefault();
		let campaign_id = $(this).data('id');
		let curElem = $(this);
		$(this).html('Please wait..');
		MainApp.promiseApiCall(METHOD_GET_SENT_EMAILS + '/' + campaign_id,'GET',{}).then(function(data){
			curElem.html('Get Sent Mail(s)');
			curElem.parent().prev().prev().prev().prev().html(data.data[0].sent_emails);
		}).catch((error) => {
			console.log('Error:', error);
			swal("Alert!", error.message, "error");
		});
		return false;
	});

		

	$('#refreshCampButton').on('click', function (evt) {
		evt.preventDefault();
		$(this).html('Please wait');
		var instance = new $.fn.dataTable.Api( '#sampleTable' );
		instance.ajax.reload();
		$(this).html('Refresh Data');
		return false;
	});

		

	$('#sampleTable').on('click', '.approveCampaign', function (evt) {
		evt.preventDefault();
		let camp_id = $(this).data('id');
		swal({
			title: "Test Email is good to send?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes',
			cancelButtonText: "Not Now"
		},function() {
			if(true){
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_PUT_UPDATE_CAMPAIGN_STATUS + '/' + camp_id,'PUT',{"status":'approved'}).then(function(data){
					$('.overlay').hide();
					swal("Success!", "Campaign approved successfully.", "success");
					var instance = new $.fn.dataTable.Api( '#sampleTable' );
					instance.ajax.reload();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			}
		});

		return false;
	});

	$('#sampleTable').on('click', '.cancelCampaign', function (evt) {
		evt.preventDefault();
		let camp_id = $(this).data('id');
		swal({
			title: "Do you want to Cancel Campaign?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes',
			cancelButtonText: "No"
		},function() {
			if(true){
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_PUT_UPDATE_CAMPAIGN_STATUS + '/' + camp_id,'PUT',{"status":'cancelled'}).then(function(data){
					$('.overlay').hide();
					swal("Success!", "Campaign cancelled successfully.", "success");
					var instance = new $.fn.dataTable.Api( '#sampleTable' );
					instance.ajax.reload();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			}
		});

		return false;
	});

	


	$('#templateTable').on('click', '.delTemplate', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No, cancel it!"
		},function() {
			if(true){
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_DEL_TEMPLATES + '/' + id,'DELETE',{}).then(function(data){
					$('.overlay').hide();
					swal("Success!", "Template deleted successfully.", "success");
					var instance = new $.fn.dataTable.Api( '#templateTable' );
					instance.ajax.reload();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});

			}
		});
	});



	/************** START upload contact **************/



	jQuery.validator.addMethod("alphanumeric", function(value, element) {
		return this.optional(element) || /^[\w_ \-]+$/i.test(value);
	}, "Only Letters, numbers, underscores and hypens allowed.");



	$("#frmEditList").validate({
		rules:{
			"list_name":{
				required: true,
				alphanumeric: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function(form){
			console.log("upload contact formsubmitted");
			console.log($(form).attr('id'));
			let list_name  =  $.trim($(form).find("input[name='list_name']").val());
			let list_id =  $.trim($(form).find("input[name='list_id']").val());
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );

			MainApp.promiseApiCall(METHOD_PUT_UPDATE_LISTS + '/' + list_id, 'PUT', { list_name: list_name}).then(function (listResponse) {
				console.log('INSIDE edit list response:', listResponse);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal({
					title: "Success!",
					text: "List updated successfully.",
					type: "success"
				}, function() {
						setTimeout(function() {
						window.location.href = "list-contactlist.html";
					}, 500);
				});
			}).catch((error) => {
					console.log('Edit list Template Error:', error);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					swal("Alert!", error.message, "error");
			});
		}
	});

	$("#frmUploadContact").validate({
		rules:{
			"list_name":{
				required: true,
				alphanumeric: true
			},
			"contact_file":{
				required: true,
				extension:"csv"
				//accept: "csv"
			}
		},
		messages: {
			"contact_file":{
				required: "Please enter CSV file.",
				extension: "Only CSV file allowed."
			}

		},


		//https://gomakethings.com/waiting-for-multiple-all-api-responses-to-complete-with-the-vanilla-js-promise.all-method/
		//for IE promises
		//https://github.com/stefanpenner/es6-promise if not worked include pollyfill
		submitHandler: function(form){
			console.log("upload contact formsubmitted");
			console.log($(form).attr('id'));
			try{
				let list_name  =  $.trim($(form).find("input[name='list_name']").val());
				let file =	document.getElementById("frmUploadContact").elements['contact_file'].files[0];
				let list_id = '';
				let allKeyPresent = false;
				$('.overlay').show();
				$(form).find("button[type='submit']").prop('disabled',true);
				$(form).find("button[type='submit']").html("Please wait..." );
				Papa.parse(file, {
					header: true,
					skipEmptyLines: true,
					delimiter: ",",
					/*quoteChar: '"',
					quotes: false,*/ //or array of booleans
					/*chunkSize: "50000", //size in bytes
					chunk: function(results, parser) {
						rows += results.data.length;
						console.log("Row data:", results.data);
						console.log("Row errors:", results.errors);
					},*/
					complete: function(results) {
						//console.log('completed',results)
						if (('firstname' in results.data[0]) && ('lastname' in results.data[0]) && ('email' in results.data[0]) && Object.size(results.data[0]) == 3 ) {
							allKeyPresent = true;
							console.log('Validated CSV');
							//console.log('before results', results.data);

							results.data = results.data.filter((csvrow) => $.trim(csvrow.firstname) !== '' && 
							$.trim(csvrow.lastname) !== '' && ($.trim(csvrow.email) !== '' &&
							/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test($.trim(csvrow.email)
							)));
							//console.log('after filtered', results.data);
							if(results.data.length > 0){
								MainApp.promiseApiCall(METHOD_POST_CREATE_LISTS, 'POST', { list_name: list_name}).then(function (listResponse) {
									console.log('INSIDE list response:', listResponse);
									list_id = listResponse.data[0].id;
									results = results.data.chunk(2500);
									console.log('results', results);
									let promises = [];
									results.map((item) => {
										promises.push(makeRequest(item,list_id));
									});

									Promise.allSettled(promises).then(function(responses){
										let callStatus = responses.map((response) => response.status);
										console.log(callStatus);
										console.log('Contact imported.');
										MainApp.promiseApiCall(METHOD_PUT_UPDATE_LIST_COUNT + '/' + list_id, 'PUT', {}).then(function (totalConRes) {
											console.log('total contact updated', totalConRes );
										});
										$('.overlay').hide();
										swal({
											title: "Success!",
											text: "List imported successfully.",
											type: "success"
										}, function() {
												setTimeout(function() {
												window.location.href = "list-contactlist.html";
											}, 500);
										});
										$(form).find("button[type='submit']").prop('disabled',false);
										$(form).find("button[type='submit']").html("Submit" );
									}).catch(function (error) {
										console.log("Error promise",error);
										$('.overlay').hide();
										$(form).find("button[type='submit']").prop('disabled',false);
										$(form).find("button[type='submit']").html("Submit" );
										swal ( "Alert!" ,  error.message ,  "error" );
									});
								}).catch((error) => {
									console.log('Error:', error);
									$('.overlay').hide();
									$(form).find("button[type='submit']").prop('disabled',false);
									$(form).find("button[type='submit']").html("Submit" );
									swal ( "Alert!" ,  error.message ,  "error" );
								});
							}else{
								$('.overlay').hide();
								$(form).find("button[type='submit']").prop('disabled',false);
								$(form).find("button[type='submit']").html("Submit" );
								swal ( "Alert!" , 'Uploaded CSV data is not correct. Please check records in csv contain valid name and email.'  ,  "error" );
							}
						}else{
							$('.overlay').hide();
							$(form).find("button[type='submit']").prop('disabled',false);
							$(form).find("button[type='submit']").html("Submit" );
							swal ( "Alert!" , 'Uploaded CSV format is not correct. Please check Sample CSV.'  ,  "error" );
						}
					}
				});
			}catch(e){
				console.log(e.message);
				$('.overlay').hide();
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
			}
			return false;

		}
	});

	$('#listTable').on('click', '.delList', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No, cancel it!"
		},function() {
			if(true){
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_DEL_LISTS + '/' + id,'DELETE',{}).then(function(data){
					$('.overlay').hide();
					swal("Success!", "List deleted successfully.", "success");
					var instance = new $.fn.dataTable.Api( '#listTable' );
					instance.ajax.reload();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});

			}
		});
	});

	$('#listTable').on('click', '.showContact', function (evt) {
		try{
			evt.preventDefault();
			let list_id = $(this).data('id');
			if ( $.fn.dataTable.isDataTable( '#contactTable' ) ) {
				//$('#contactTable').find('.dataTables_empty').html('Loading...');
				$('#contactTable').find('tbody').html('<tr class="odd"><td valign="top" colspan="4" class="dataTables_empty">Loading..</td></tr>');
				$('#contactTable').DataTable().ajax.url( METHOD_GET_CONTACTS + '/' + list_id).load();
				//table.ajax.url( METHOD_GET_CONTACTS + '/' + list_id).load();
			}else{
				MainApp.loadContactTable('#contactTable',list_id);
				$('#contactTable').find('tbody').html('<tr class="odd"><td valign="top" colspan="4" class="dataTables_empty">Loading..</td></tr>');
				$('#contactTable').DataTable().ajax.url( METHOD_GET_CONTACTS + '/' + list_id).load();
			}
			$('#contactModal').modal('show');
		}catch(error){
			console.log('Error:', error);
			$('.overlay').hide();
			swal("Alert!", error.message, "error");
		}
	});



	function makeRequest(records,list_id){

		return fetch(METHOD_POST_CREATE_CONTACTS,
		{
			headers: {
				'Content-Type': 'application/json',
				"Authorization": getCookie('authToken')
			},
			method: "POST",
			body: JSON.stringify({"list_id": list_id, "contacts": records})
		});
	}

	/************** ENd upload contact **************/



/**** START SEND TEST EMAIL ***************/
	$("#frmSendTestEmail").validate({
		rules:{
			"admin_email":{
				required: true
			},
			"campaign_name":{
				required: true,
				alphanumeric: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"contact_list":{
				required: true
			},
			"template_name":{
				required: true
			}
		},
		messages: {
			"admin_email":{
				required: "Please select Admin Mailbox."
			},
			"contact_list":{
				required: "Please select Contact list."
			},
			"template_name":{
				required: "Please Select Template."
			}

		},

		submitHandler: function(form){
			console.log("formsubmitted");
			console.log($(form).attr('id'));
			let campaign_name  =  $(form).find("input[name='campaign_name']").val();
			let admin_email  =  $(form).find("select[name='admin_email']").val();
			let contact_list =  $(form).find("select[name='contact_list']").val();
			let template  =  $(form).find("select[name='template_name']").val();
			let user_id = JSON.parse(getCookie('loggedInUser')).id;
			//$('.overlay').show();
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			console.log(admin_email,contact_list,template);
			MainApp.promiseApiCall(METHOD_POST_CREATE_CAMPAIGNS,'POST',
				{ campaign_name: campaign_name, admin_email_id: admin_email, list_id: contact_list, template_id: template, user_id: user_id }).then(function(data){
					console.log('SENT TEST EMAIL', data);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					//$('.overlay').hide();
					var instance = new $.fn.dataTable.Api( '#sampleTable' );
					instance.ajax.reload();
					swal('Success!', 'Test Email sent successfully. Please check your mailbox.', "success");
				}).catch((error) => {
					console.log('SENT TEST EMAIL Error:', error);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					//$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			return false;
		}
	});
/************* END TEST EMAIL ***************************************/

/**** CHANGE PASSWORD *****/
MainApp.initAjaxRequest();

$("#frmChangePassword").validate({
	onkeyup: false,
	focusCleanup: true,
	rules:{
		"old_password":{
			required: true,
			normalizer: function(value) {
				return $.trim(value);
			},
			remote: {
				url: METHOD_POST_CHECK_OLD_PASSWORD,
				type: "POST",
				contentType: 'application/json',
				dataType: "json",
				data:{
					"old_password": function() {
						return $('#frmChangePassword').find("input[name='old_password']").val();
					},
					"user_id": function(){
						if(getCookie('loggedInUser').length){
							return JSON.parse(getCookie('loggedInUser')).id;
						}else{
							return 0;
						}
					}
				},
				cache: false
			}
		},
		"new_password":{
			required: true,
			minlength : 5,
			normalizer: function(value) {
				return $.trim(value);
			}
		},
		"password_confirm" : {
			required: true,
			minlength: 5,
			normalizer: function(value) {
				return $.trim(value);
			},
			equalTo : "#new_password"
		}

	},
	messages: {
		"old_password":{
			required: "Please enter Old Password.",
			remote: "Old Password is not correct."
		},
		"new_password":{
			required: "Please enter New Password.",
		},
		"password_confirm":{
			required: "Please enter Confirm Password.",
		},

	},

	submitHandler: function(form){
		console.log("formsubmitted");
		console.log($(form).attr('id'));
		let new_password  =  $(form).find("input[name='new_password']").val();
		let user_id = JSON.parse(getCookie('loggedInUser')).id;

		$(form).find("button[type='submit']").prop('disabled',true);
		$(form).find("button[type='submit']").html("Please wait..." );

		MainApp.promiseApiCall(METHOD_POST_CHANGE_PASSWORD,"POST",
			{ "user_id" : user_id, "new_password": new_password}).then(function(data){
				console.log('password changed', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				$(form).find("input[type='password']").val('');

				swal('Success!', 'Password changed successfully.', "success");
			}).catch((error) => {
				console.log('Crate Template Error:', error);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Alert!", error.message, "error");
			});
		return false;
	}
});

function getPostData(){
	console.log('gging');
	return JSON.stringify({user_id:1,old_password: $('#frmChangePassword').find("input[name='new_password']").val()})
}

/*****CHANGE PASSWORD *****/

/**** START: FORGOT PASSWORD **********************/

$("#frmForgotPassword").validate({
	rules:{
		"email":{
			required: true,
			email: true,
			normalizer: function(value) {
				return $.trim(value);
			}
		}
	},
	messages: {
		"email":{
			required: "Please enter Email."
		}
	},

	submitHandler: function(form){
		console.log("formsubmitted");
		console.log($(form).attr('id'));
		let email  =  $(form).find("input[name='email']").val();
		console.log(email);
		$(form).find("button[type='submit']").prop('disabled',true);
		$(form).find("button[type='submit']").html("Please wait..." );
		MainApp.promiseApiCall(METHOD_POST_SEND_PASSWORD_RESET_LINK,"POST",
			{"email": email}).then(function(data){
				console.log('email sent.', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html('<i class="fa fa-unlock fa-lg fa-fw"></i>RESET');
				$(form).find("input[type='text']").val('');
				swal('Success!', 'Instructions for resetting password has been sent on your Email successfully.', "success");
			}).catch((error) => {
				console.log('Crate Template Error:', error);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Success!", "Instructions for resetting password has been sent on your Email successfully.", "success");
			});
		return false;
	}
});
/**** END: FORGOT PASSWORD ***************/

/**** START: RESET PASSWORD **********************/

$("#frmResetPassword").validate({
	rules:{
		"password":{
			required: true,
			minlength : 5,
			normalizer: function(value) {
				return $.trim(value);
			}
		},
		"confirm_password" : {
			required: true,
			minlength: 5,
			normalizer: function(value) {
				return $.trim(value);
			},
			equalTo : "#password"
		}
	},
	messages: {
		"password":{
			required: "Please enter Password.",
		},
		"confirm_password":{
			required: "Please enter Confirm Password.",
		},
	},

	submitHandler: function(form){
		console.log("formsubmitted");
		console.log($(form).attr('id'));
		let new_password  =  $(form).find("input[name='password']").val();
		let token  =  $(form).find("input[name='token']").val();
		let email  =  $(form).find("input[name='email']").val();
		let user_id  =  $(form).find("input[name='user_id']").val();
		if(email == '' || token == '' || user_id == '' ){
			swal("Alert!", "Link not correct.", "error");
			return false;
		}else{
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			MainApp.promiseApiCall(METHOD_POST_RESET_PASSWORD,"POST",
			{"email": email,"new_password": new_password,"token": token, "user_id": user_id}).then(function(data){
				console.log('email sent.', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html('<i class="fa fa-unlock fa-lg fa-fw"></i>RESET');
				$(form).find("input[type='text']").val('');
				swal('Success!','Password resetted successfully.','success');
				setTimeout(() => window.location.href = 'index.html', 3000);
			}).catch((error) => {
				console.log('Crate Template Error:', error);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				swal("Alert!", error.message, "error");
			});
		}
		return false;
	} /** submit handler */
});


/**** END: FORGOT PASSWORD ***************/




});


Object.defineProperty(Array.prototype, 'chunk', {
  value: function(chunkSize) {
    var R = [];
    for (var i = 0; i < this.length; i += chunkSize)
      R.push(this.slice(i, i + chunkSize));
    return R;
  }
});

Object.size = function(obj) {
	var size = 0;
	var key;
	for (key in obj) {
	  if (obj.hasOwnProperty(key)) size++;
	}
	return size;
  };
