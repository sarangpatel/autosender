// var SITE_URL = 'https://novaproduct.net/autosender/';
// var APP_SITE_URL = 'https://novaproduct.net/autosender/app/';

var SITE_URL = 'http://localhost/autosender/';
var APP_SITE_URL = 'http://localhost/autosender/app/';


//var globalDateFormat = 'DD MMM YYYY';
var globalDateFormat = 'LL';
var globalDateFormatForm = 'YYYY-MM-DD';
var globalDateTimeFormat = 'DD MMM YYYY, h:mm:ss a';
