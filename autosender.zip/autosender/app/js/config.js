//var env = 'prod';
var env = 'local';

var templateCreateMicroService, templateUpdateMicroService, templateGetMicroService, templateDelMicroService;
var adminEmailGetMicroService;
var loginMicroService;
var contactMicroservice;
//var sendTestEmailMicroservice
var campaignMicroservice;
var userMicroservice;
var siteURL;
if (env === 'local') {

	//templates
	templateCreateMicroService = 'http://localhost:3001/local/api/';
	templateUpdateMicroService = 'http://localhost:3002/local/api/';
	templateGetMicroService = 'http://localhost:3003/local/api/';
	templateDelMicroService = 'http://localhost:3004/local/api/';

	//adminEmails
	adminEmailGetMicroService = 'http://localhost:3015/local/api/';

	//login
	loginMicroService = 'http://localhost:3016/local/api/';

	//contact
	contactMicroservice = 'http://localhost:3017/local/api/';

	//send test email
	//sendTestEmailMicroservice = 'http://localhost:3018/local/api/';

	//campaign microservice
	campaignMicroservice = 'http://localhost:3020/local/api/';

	//user microservice = 
	userMicroservice =  'http://localhost:3021/local/api/' ;

} else if (env === 'prod') {

	//templates
	templateCreateMicroService = 'https://1n101f2o6g.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateUpdateMicroService = 'https://5k2nff5x0m.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateGetMicroService = 'https://dy5nrzct8i.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateDelMicroService = 'https://e7z6mzr20j.execute-api.us-east-2.amazonaws.com/prod/api/';

	//adminEmails
	adminEmailGetMicroService = 'https://yax4v29wpk.execute-api.us-east-2.amazonaws.com/prod/api/';

	//login
	loginMicroService = 'https://q3hquixz0i.execute-api.us-east-2.amazonaws.com/prod/api/';

	//contact
	contactMicroservice = 'https://crz4ymyjoh.execute-api.us-east-2.amazonaws.com/prod/api/';

	//send test email
	//sendTestEmailMicroservice = 'http://localhost:3018/local/api/';

	//campaign microservice
	campaignMicroservice = 'https://wnicggd2s1.execute-api.us-east-2.amazonaws.com/prod/api/';

	//user microservice = 
	userMicroservice =  'https://2aabfd3jpi.execute-api.us-east-2.amazonaws.com/prod/api/' ;
}

var appLandingPage = 'list-template.html';
var globalDateFormat = 'DD MMM YYYY';
var globalDateTimeFormat = 'DD MMM YYYY, h:mm:ss a';
var globalKeepLoggedIn = (60 * 60 * 24) * 7; //7 days
var globalSite = 'http://localhost/tsumailapp/frontend/';

//START : TEMPLATES
const METHOD_CREATE_TEMPLATES = templateCreateMicroService + 'createTemplates';
const METHOD_UPDATE_TEMPLATES = templateUpdateMicroService + 'updateTemplates';
const METHOD_GET_TEMPLATES = templateGetMicroService + 'getTemplates';
const METHOD_DEL_TEMPLATES = templateDelMicroService + 'deleteTemplates';
//END : TEMPLATES


//START : ADMINEMAILS
const METHOD_GET_ADMIN_EMAILS = adminEmailGetMicroService + 'getAdminEmails';
//END : ADMINEMAILS


//START : Login
const METHOD_POST_LOGIN = loginMicroService + 'login';
//END : Login

//START : Contact
const METHOD_POST_CREATE_LISTS = contactMicroservice + 'createLists';
const METHOD_PUT_UPDATE_LISTS = contactMicroservice + 'updateLists';
const METHOD_PUT_UPDATE_LIST_COUNT = contactMicroservice + 'updateListContactCount';
const METHOD_GET_LISTS = contactMicroservice + 'getLists';
const METHOD_DEL_LISTS = contactMicroservice + 'deleteLists';

const METHOD_POST_CREATE_CONTACTS = contactMicroservice + 'createContacts';
const METHOD_GET_CONTACTS = contactMicroservice + 'getContacts';
//END : Contact

//START: SEND TEST EMAIL
//const METHOD_POST_SEND_TEST_EMAIL = sendTestEmailMicroservice + 'sendTestEmail';
//START: SEND TEST EMAIL

//START: CAMPAIGN
const METHOD_POST_CREATE_CAMPAIGNS = campaignMicroservice + 'createCampaigns';
const METHOD_GET_CAMPAIGNS = campaignMicroservice + 'getCampaigns';

const METHOD_PUT_UPDATE_CAMPAIGN_STATUS = campaignMicroservice + 'updateCampaignStatus';
const METHOD_GET_SENT_EMAILS = campaignMicroservice + 'getSentEmailCount';
//END: CAMPAIGN

//START: USER
const METHOD_POST_CHECK_OLD_PASSWORD = userMicroservice + 'checkOldPassword';
const METHOD_POST_CHANGE_PASSWORD = userMicroservice + 'changePassword';
const METHOD_POST_SEND_PASSWORD_RESET_LINK = userMicroservice + 'sendPasswordResetLink';
const METHOD_POST_RESET_PASSWORD = userMicroservice + 'resetPassword';
//END: USER
