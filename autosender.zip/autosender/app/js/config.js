var SITE_URL = 'http://localhost/autosender/';
var APP_SITE_URL = 'http://localhost/autosender/app/';

//var globalDateFormat = 'DD MMM YYYY';
var globalDateFormat = 'LL';

var globalDateTimeFormat = 'DD MMM YYYY, h:mm:ss a';