var SITE_URL = 'http://localhost/autosender/';
var APP_SITE_URL = 'http://localhost/autosender/app/';