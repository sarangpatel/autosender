function removeCookie(cname, cval) {
    console.log(cname)
    document.cookie = cname + "=" + cval + ";expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;";

}

function setCookie(cname, cvalue, seconds) {
    if (seconds == 0) {
        document.cookie = cname + "=" + cvalue + "; path=/";
    } else {
        var d = new Date();
        d.setTime(d.getTime() + (seconds * 1000)); //seconds * 1000 = miliseconds
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + "; path=/";
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}



function getToken(tokenName) {
    return getCookie(tokenName);
}

function removeToken() {
    removeCookie('authToken', '');
    removeCookie('isLoggedin', '');
    removeCookie('loggedInUser', '');
}


function updateAccessToken(refreshTokenData) {
    let accessToken = refreshTokenData['AccessToken'];
    let idToken = refreshTokenData['IdToken'];
    setCookie('accessToken', accessToken, 60 * 60); //1 hour = 3600 seconds
    setCookie('idToken', idToken, 60 * 60); //1 hour = 3600 second
}

function formatDateTime(datetime) {
    return moment(datetime).format(globalDateTimeFormat);
}

function formatDate(datetime) {
    return moment(datetime).format(globalDateFormat);
}

function formatTime(datetime) {
    return moment(datetime).format(globalTimeFormat);
}

function nl2br(str, is_xhtml) {
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}

//day: 12th apr 2020, 22nd may 2020
function getSupOfDate(date) {
    return date.replace(/(\d)(st|nd|rd|th)/g, '$1<sup>$2</sup>');
}


function datediff(first, second) {
    var date1 = new Date(first);
    var date2 = new Date(second);
    var Difference_In_Time = date2.getTime() - date1.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    return Math.round(Difference_In_Days);
}


