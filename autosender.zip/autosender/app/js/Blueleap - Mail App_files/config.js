var env = 'local';


var templateCreateMicroService, templateUpdateMicroService, templateGetMicroService, templateDelMicroService;
var adminEmailGetMicroService;
var loginMicroService;
var siteURL;
if (env === 'local') {

	//templates
	templateCreateMicroService = 'http://localhost:3001/local/api/';
	templateUpdateMicroService = 'http://localhost:3002/local/api/';
	templateGetMicroService = 'http://localhost:3003/local/api/';
	templateDelMicroService = 'http://localhost:3004/local/api/';

	//adminEmails
	adminEmailGetMicroService = 'http://localhost:3015/local/api/';

	//login
	loginMicroService = 'http://localhost:3016/local/api/';

} else if (env === 'prod') {

	//templates
	templateCreateMicroService = 'https://1n101f2o6g.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateUpdateMicroService = 'https://5k2nff5x0m.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateGetMicroService = 'https://dy5nrzct8i.execute-api.us-east-2.amazonaws.com/prod/api/';
	templateDelMicroService = 'https://e7z6mzr20j.execute-api.us-east-2.amazonaws.com/prod/api/';

	//adminEmails
	adminEmailGetMicroService = 'https://7k1xnqjqik.execute-api.us-east-2.amazonaws.com/prod/api/';

	//login
	loginMicroService = 'https://q3hquixz0i.execute-api.us-east-2.amazonaws.com/prod/api/';

}

var appLandingPage = 'list-template.html';
var globalDateFormat = 'DD MMM YYYY';
var globalDateTimeFormat = 'DD MMM YYYY, h:mm:ss a';
var globalKeepLoggedIn = (60 * 60 * 24) * 7; //7 days
var globalSite = 'http://localhost/tsumailapp/frontend/';

//START : TEMPLATES
const METHOD_CREATE_TEMPLATES = templateCreateMicroService + 'createTemplates';
const METHOD_UPDATE_TEMPLATES = templateUpdateMicroService + 'updateTemplates';
const METHOD_GET_TEMPLATES = templateGetMicroService + 'getTemplates';
const METHOD_DEL_TEMPLATES = templateDelMicroService + 'deleteTemplates';
//END : TEMPLATES


//START : ADMINEMAILS
const METHOD_GET_ADMINTEMPLATES = adminEmailGetMicroService + 'getAdminEmails';
//END : TEMPLATES

//START : Login
const METHOD_POST_LOGIN = loginMicroService + 'login';
//END : Login

