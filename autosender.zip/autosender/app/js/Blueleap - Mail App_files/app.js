"use strict";
var MainApp;

$(document).ready(function () {
	MainApp = function () {

			//MainApp.isLogin()
			MainApp.prototype.isLogin = function () {
				let isLoggedIn = getCookie('isLoggedin');
				if (typeof isLoggedIn !== 'undefined' && isLoggedIn != '') {
					return true;
				} else {
					//window.location.href = globalSite + 'index.html';
					return false;
				}
			},
			MainApp.prototype.previewTemplate = function (content) {
				var left = (screen.width - 800) / 2;
				var top = (screen.height - 800) / 4;
				var win = window.open("", "Template - Preview", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes," + 
					" width=800,height=700,top="+top+",left="+left);
					win.document.body.innerHTML = content;
			},
			MainApp.prototype.signOut = function () {
				removeToken();
				console.log('signout successfully', "");
				window.location.href = "index.html";
			},
			MainApp.prototype.login = function (email, password) {
				return new Promise(function(resolve,reject){
					console.log('Login...');
					MainApp.promiseApiCall(METHOD_POST_LOGIN, 'POST', { email: email, password: password }).then(function (user) {
						console.log('INSIDE login:', user);
						setCookie('authToken', user.data[0]['token'], globalKeepLoggedIn); //30 days
						setCookie('isLoggedin', 1, globalKeepLoggedIn); //30 days
						setCookie('loggedInUser', JSON.stringify(user.data[0]), globalKeepLoggedIn);//30 days
						resolve('sucess');
						//window.location.href = appLandingPage;
					}).catch((error) => {
						console.log('Error:', error);
						reject(error);
						//swal ( "Oops" ,  error.message ,  "error" );
					});
				});
			},
			MainApp.prototype.initAjaxRequest = function () {
				$.ajaxSetup({
					beforeSend: function (xhr) {
						xhr.setRequestHeader('Authorization', getCookie('authToken'));
					}
				});
			},
			MainApp.prototype.getQueryParams = function (name) {
				name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
				var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
				var results = regex.exec(location.search);
				return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
			},
			MainApp.prototype.promiseApiCall =function(method,method_type,data){
				return new Promise((resolve, reject) => {
					try{
						 MainApp.initAjaxRequest();
						 if(method_type == 'POST' || method_type == 'PUT'  ){
							  if(data){
								data = JSON.stringify(data);
							  }else{
								data = JSON.stringify({});
							  }
						 }
						  $.ajax({
								url : method,
								type: method_type,
								dataType: 'json',
								contentType: 'application/json',
								data: data
						  })
						  .done(function( data, textStatus, jQxhr ){
								console.log('ajaxsucess');
								if(data.code === 1) //SUCCESS
								resolve(data);
								else
								reject({ 'message' : 'ERROR: ' +   data.message, 'data' : data.data});
							})
						  .fail(function( jqXhr, textStatus, errorThrown ){
								//reject({ 'message' : 'API ERROR: ' +  JSON.stringify(jqXhr), 'data' : data.data});
								reject({ 'message' : 'ERROR: ' +  jqXhr.responseJSON.message, 'data' : jqXhr.responseJSON.data});
							});
					}catch(e){
						reject({ 'message' : 'ERROR(catch): ' +  e.message, 'data' : data.data});
					}
				});
			},
			MainApp.prototype.getCategories =  function(){
				return new Promise(function(resolve,reject){
					MainApp.promiseApiCall(METHOD_GETCATEGORIES,'GET',{},{}).then(function(data){
						console.log('Categories: Success');
						resolve(data.result.result);
					}).catch((error) => {
						console.log('Error:', error);
						resolve([]);
					});
				});
			},
			MainApp.prototype.getRowProperties = function(row){
				let estr='';
				for (const prop in row) {
					if(prop == 'content')continue;
					estr += ' data-' + prop + ' = "' + MainApp.htmlEntities(row[prop]) + '" ';
				}
				return estr;
			},
			MainApp.prototype.htmlEntities = function(str){
				return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
			},
			MainApp.prototype.loadDynamicTable = function(auth,tblId,url,cols,coldefs,colsorts,cb,paging){
				console.log('inside load dynamic table');
				try{
					 if(auth){
						MainApp.initAjaxRequest();
					}
					$('.overlay').show();

					let table = $(tblId).DataTable({
						 'lengthChange': true,
						 'paging'      : paging,
						 'lengthChange': true,
						 'searching'   : true,
						 'ordering'    : true,
						 /*'dom': 'Bfrtip',*/
						 /*'dom': 'Bfrtip',
						 'buttons': [
						 'copy', 'csv', 'excel', 'pdf', 'print'
						 ],*/
						 'initComplete': function () {
						  },
						'ajax' : {
						  'url' : url,
						  'dataSrc': function(json){
								$('.overlay').hide();
								if(parseInt(json.code) === 0){
									swal("Alert!", json.message, "error");
									return {};
								}
								if(json.data == null)return {}
								if(json.code === 1){
									return json.data;
								}else {
									swal("Alert!", json.message, "error");
									return {}
								}
						   },
						  'error': function( jqXhr, textStatus, errorThrown ){
							$('.overlay').hide();
							$(tblId).find('.dataTables_empty').html(textStatus.toUpperCase() +  ': Error getting data from Server.');
						  }
						},
						'columns': cols,
						select: true,
						colReorder: true,
						/*buttons: [
							{
								extend: 'collection',
								text: 'Export',
								buttons: [
									'excel'
								]
							}
						],*/
						'columnDefs': coldefs == null ? '' : coldefs,
						'order': colsorts == null ? [] : colsorts,
						'responsive': true
					  });
					 return table;
				}catch(e){
					// alert(e.message);
					swal("Alert!", e.message, "error");
					return table;
				}
			},
			MainApp.prototype.loadEditTemplate = function(frmId){
				console.log("loading edit template");
				let template_id = MainApp.getQueryParams('template_id');
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_GET_TEMPLATES + '/' + template_id,'GET',{}).then(function(data){
					$(frmId).find('input[name = "template_id"]').val(data.data[0].id);
					$(frmId).find('input[name = "template_name"]').val(data.data[0].name);
					$(frmId).find('input[name = "template_subject"]').val(data.data[0].subject);
					$(frmId).find('textarea[name = "template_content"]').val(data.data[0].content);
					$('.overlay').hide();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			},
			MainApp.prototype.loadTemplateTable = function(tblId){
				console.log("loading template table");
				let cols  =  [
					{ data: 'name' },
					{data: 'subject'},
					{ mRender: function (data, type, row) {
						return moment(row.created_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						return moment(row.updated_on).format(globalDateTimeFormat); 
						}
					},
					{ mRender: function (data, type, row) {
						let attr = MainApp.getRowProperties(row);
						return '<a href="edit-template.html?template_id=' + row.id + '" class="btn btn-primary">Edit</a>' + 
							'&nbsp;<a href="#"' +  attr   + ' class="btn btn-primary delTemplate">Delete</a>';
						}
					}
				];
				let coldefs = [
					{ orderable: false, targets: -1 },
				];
				/*let colsorts = [[ 1, "desc" ]];*/
				let colsorts = null;
				return MainApp.loadDynamicTable(true,tblId, METHOD_GET_TEMPLATES,
						cols,coldefs,colsorts,'',true);
			},
			MainApp.prototype.init = function () {
				return new Promise(function (resolve, reject) {
					resolve('app initialized');
				});
			}
		};
	MainApp = new MainApp;
	(function () {
		try {
			var initApp = MainApp.init();
			initApp.then(function (r) {
				console.log(r);
				if(MainApp.isLogin()){
					console.log('logged in');
					$('.header-welcome-msg').html('Welcome ' + JSON.parse(getCookie('loggedInUser')).full_name);
					if ($('#templateTable').length) {
						MainApp.loadTemplateTable('#templateTable');
					}
					if($('#frmEditTemplate').length){
						MainApp.loadEditTemplate('#frmEditTemplate');
					}
				}else{
					let winloc = window.location.href;
					let page = winloc.substring(winloc.lastIndexOf("/"));
					console.log('page', page);
					if(!(page == '/' || page == '/index.html' || page == ''))//if not login / home page
					window.location.href = 'index.html';
				}
			});
		} catch (e) {
			console.log('error', e.message);
		}
	})();
	
	$('.app-header').on('click', '.signout', function (evt) {
		evt.preventDefault();
		MainApp.signOut();
	});

	$('main.app-content').on('click', '#templatePreviewBtnId', function (evt) {
		evt.preventDefault();
		console.log($(this).closest('form').attr('name'));
		let content = $(this).closest('form').find('textarea[name="template_content"]').val();
		if($.trim(content) == '')content = 'No content';
		MainApp.previewTemplate(content);
	});


	$('main.app-content').on('click', '#templateViewPlaceholderBtnId', function (evt) {
		evt.preventDefault();
		$('#template-placeholders').slideToggle('fast');
	});
	


	$("#frmNewTemplate,#frmEditTemplate").validate({
		rules:{
			"template_name":{
				required: true
			},
			"template_subject":{
				required: true
			},
			"template_content":{
				required: true
			}
		},
		messages: {
			"template_name":{
				required: "Please enter Template Name."
			},
			"template_subject":{
				required: "Please enter Template Subject."
			},
			"template_content":{
				required: "Please enter Template Content."
			}

		},

		/*errorPlacement: function (error, element) {
			if (element.attr("type") == "checkbox") {
				error.insertAfter($(element).parent().parent());
			} else {
				// something else
			}
		},*/

		submitHandler: function(form){
			console.log("formsubmitted");
			console.log($(form).attr('id'));
			let template_name  =  $(form).find("input[name='template_name']").val();
			let template_subject  =  $(form).find("input[name='template_subject']").val();
			let template_content =  $(form).find("textarea[name='template_content']").val();
			let apiURL = METHOD_CREATE_TEMPLATES;
			let apiMethod = 'POST';
			let succMsg = 'created';
			if($(form).attr('id') === 'frmEditTemplate' ){
				apiURL = METHOD_UPDATE_TEMPLATES + '/' + $(form).find("input[name='template_id']").val();
				apiMethod = 'PUT';
				succMsg = 'updated';
			}
			$('.overlay').show();
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );

			MainApp.promiseApiCall(apiURL,apiMethod,
				{ name: template_name, subject: template_subject, content: template_content}).then(function(data){
					console.log('CRUD template', data);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					$('.overlay').hide();
					swal('Success!', 'Template ' + succMsg + ' successfully.', "success");
				}).catch((error) => {
					console.log('Crate Template Error:', error);
					$(form).find("button[type='submit']").prop('disabled',false);
					$(form).find("button[type='submit']").html("Submit" );
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});
			return false;
		}
	});

	$('#templateTable').on('click', '.delTemplate', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No, cancel it!"
		},function() {
			if(true){
				$('.overlay').show();
				MainApp.promiseApiCall(METHOD_DEL_TEMPLATES + '/' + id,'DELETE',{}).then(function(data){
					$('.overlay').hide();
					swal("Success!", "Template deleted successfully.", "success");
					var instance = new $.fn.dataTable.Api( '#templateTable' );
					instance.ajax.reload();
				}).catch((error) => {
					console.log('Error:', error);
					$('.overlay').hide();
					swal("Alert!", error.message, "error");
				});

			}
		});
	});


	/*if($("#frmNewArticle").length){
		$("#frmNewArticle").validate({
			errorPlacement: function (error, element) {
				if (element.is(":checkbox")) {
					element.parent().append(error);
				}else{
					error.insertAfter(element);
				}
			}
		});
		if($('#edit-article-page').length){
			$('textarea[name="art_subtitle"]').rules('remove');
			$('textarea[name="art_optionaltitle"]').rules('remove');
			$('textarea[name="title"]').rules('add', {
				required: true 
			});
		}
	}*/


	/*$('#save-and-publish').click(function() {
		if($("#frmNewArticle").valid()){
			$('#submit_type').val('save-and-publish');
			frmNewArticleSubmitted("#frmNewArticle");
		}
	});*/
	
	/*$.validate({
		form : '#frmUserProfile',
		onSuccess : frmUserProfileSubmitted
	});*/

	
	/*function frmNewArticleSubmitted($form){
		if(!MainApp.isLogin()){
			//alert("Please Sign In to submit article.");
			swal("Info!", "Please Sign In to submit article.", "info");
		}else{
			try{
				let meta_keywords   = $($form).find('input[name="meta_keywords"]').val();
				MainApp.promiseApiCall(METHOD_ADDARTICLE,'POST',{category_ids:selected, user_id:user_id, title: title, meta_keywords:meta_keywords, subtitle:subtitle, meta_desc:meta_desc, agreed_tnc:1,  publish: is_publish, html_content: html_content, content: md_content,article_mime:article_mime,thumbnail_img_url:thumbnail_img_url,optionaltitle:optionaltitle,url:url,language:language},{}).then(function(data){
				}).catch((error) => {
					console.log('Error:', error);
					swal("Alert!", error.message, "error");
				});
			}catch(e){
				console.log(e.message)
			}
		}
		return false;
	}*/

/*	$(document).on('click', '.delete-article',function(ev){
		ev.preventDefault();
		 var id = this.id.replace(/deleteByLink_/, '');
		deleteArticle(id);
		return false;
	});

	function deleteArticle(id){
		if(!MainApp.isLogin()){
			// alert("Please Sign In to delete article.");
			swal("Info!", "Please Sign In to delete article.", "info");
		}else{
			let user_id	   = JSON.parse(getCookie('loggedInUser')).id;
			try {
				MainApp.promiseApiCall(METHOD_DELETEARTICLE,'POST',{ article_id:id,user_id:user_id},{}).then(function(data){
					console.log("data : " + data.message);
					// alert('Article deleted.');
					swal("Success!", "Article deleted.", "success");
					window.location.href = globalSite + 'user-submitted-article.html';
				}).catch((error) => {
					console.log('Error:', error);
					// alert('Error:' + error.message);
					swal("Alert!", error.message, "error");
				});
			} catch (error) {
				console.log(error.message);	
			}
		}
		return false;
	}

	function showsubscribeModal(){
		$('#subscribeModal').modal('show');
		$("#subscribeModal").modal({
			backdrop: 'static',
			keyboard: false
		});
	}
*/

/*	function frmUserProfileSubmitted($form){
		if(!MainApp.isLogin()){
			swal("Info!", "Please Sign In to submit profile.", "info");
		}else{
			try{
				let full_name     = $($form).find('input[name="full_name"]').val();
				let email_id = $($form).find('input[name="email"]').val();
				let bio = $($form).find('textarea[name="bio"]').val();
				let fb_link = $($form).find('input[name="fb_link"]').val();
				let twitter_link = $($form).find('input[name="twitter_link"]').val();
				let youtube_link = $($form).find('input[name="youtube_link"]').val();
				let insta_link = $($form).find('input[name="insta_link"]').val();
				let snap_link = $($form).find('input[name="snap_link"]').val();
				let user_id	   = JSON.parse(getCookie('loggedInUser')).id;
				MainApp.promiseApiCall(METHOD_UPDATEPROFILE,'POST',{ user_id: user_id, email: email_id, bio:bio, full_name: full_name, fb_link: fb_link,
						twitter_link:twitter_link, insta_link:insta_link, youtube_link: youtube_link, snap_link: snap_link},{}).then(function(data){
					console.log('INSIDE frmUserProfileSubmitted:: Update Profile response',  data);
					let user = JSON.parse(getCookie('loggedInUser'));
					user.bio =  bio;
					user.full_name =  full_name;
					user.email_id =  email_id;
					user.fb_link =  fb_link;
					user.twitter_link =  twitter_link;
					user.youtube_link =  youtube_link;
					user.snap_link =  snap_link;
					user.insta_link =  insta_link;
					setCookie('loggedInUser', JSON.stringify(user), globalKeepLoggedIn);
					swal("Success!", "Profile updated successfully.", "success");
					$('.upload-demo-wrap').hide();
					$($form).find('input[name="full_name"]').focus();
				}).catch((error) => {
					console.log('Error:', error);
					swal("Alert!", error.message, "error");
				});
			}catch(e){
				console.log(e.message)
			}
		}
		return false;
	}

	$("#frmNewForm").validate({
		errorPlacement: function (error, element) {
			error.insertAfter(element);
		}
	});
*/

});
