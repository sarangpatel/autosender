(function () {
	"use strict";

	let contactTable;
	let templateTable;
	let outboxTable;
	var treeviewMenu = $('.app-menu');

	// Toggle Sidebar
	$('[data-toggle="sidebar"]').click(function (event) {
		event.preventDefault();
		$('.app').toggleClass('sidenav-toggled');
	});

	// Activate sidebar treeview toggle
	$("[data-toggle='treeview']").click(function (event) {
		event.preventDefault();
		if (!$(this).parent().hasClass('is-expanded')) {
			treeviewMenu.find("[data-toggle='treeview']").parent().removeClass('is-expanded');
		}
		$(this).parent().toggleClass('is-expanded');
	});

	// Set initial active toggle
	$("[data-toggle='treeview.'].is-expanded").parent().toggleClass('is-expanded');

	//Activate bootstrip tooltips
	$("[data-toggle='tooltip']").tooltip();

	$(function () {
		$.validator.addMethod("nameChars", function (value, element) {
			return this.optional(element) || /^[a-z0-9\-_'\s]+$/i.test(value);
		}, "Field must contain only letter, numbers, underscores or dashes");

		$.validator.addMethod("phoneNum", function (value, element) {
			return this.optional(element) || /^\+\d{10,}$/i.test(value);
		}, "Phone Number should have below pattern: +17879798797");

		$.validator.addMethod("alphaPlusSpecial", function (value, element) {
			return this.optional(element) || /^[a-z0-9=\[\]\{\}\*/\-_\?&!@\$%\(\)\+\|"';,#\.'\s]+$/i.test(value);
		}, "Mentioned chars not allowed.");


		$.validator.addMethod("greaterThan", function (value, element, params) {
			console.log(value, element, params);
			if (this.optional(element)) {  // "required" not in force and field is empty
				return true;
			}else{
				let formParams = params.split(',');
				let start_date = $(formParams[0]).find(formParams[1]).val();
				console.log('start_date', start_date);
				return new Date(value) >= new Date(start_date);
			}
		}, 'Must be greater than Start Date.');

		// var dateFrom = $("#valid_from").val();
		// var dateTo = $('#valid_to').val();
		// return dateTo > dateFrom;

	});


	$("#frmAddContact").validate({
		rules: {
			"first_name": {
				required: true,
				nameChars: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"last_name": {
				nameChars: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"email": {
				required: true,
				email: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"phone": {
				//phoneUS: true,
				//digits: true,
				minlength: 10,
				phoneNum: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"start_date": {
				required: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"end_date": {
				normalizer: function (value) {
					return $.trim(value);
				},
				greaterThan: "form[name='frmAddContact'],input[name='start_date']"

			},
			"template_id": {
				required: true
			}



		},
		submitHandler: function (form) {
			console.log("add contact form formsubmitted");
			console.log($(form).attr('id'));
			//let background_img = $('#frmAddContact').find('select[name="background_img"]').val();
			$(form).find("button[type='submit']").prop('disabled', true);
			$(form).find("button[type='submit']").html("Please wait...");
			$.ajax({
				url: APP_SITE_URL + 'ajax/add_contact.php',
				type: 'POST',
				dataType: 'json',
				data: $(form).serialize(),
				cache: false
			})
				.done(function (data, textStatus, jQxhr) {
					console.log('ajaxsucess', data);
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");
					if (data.error == true) {
						swal("Alert!", data.msg, "error");
					} else {
						//swal('Success!', 'Contact added successfully.' , "success");
						swal({ title: 'Success!', icon: "success", text: 'Contact added successfully.', timer: 1200 });

						contactTable.ajax.reload();

					}
				})
				.fail(function (jqXhr, textStatus, errorThrown) {
					console.log('fail', 'message:', textStatus);
					swal("Alert!", textStatus, "error");
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");

				});

			return false;
		}
	});

	$("#frmUpdateContact").validate({
		rules: {
			"first_name": {
				required: true,
				nameChars: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"last_name": {
				nameChars: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"email": {
				required: true,
				email: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"phone": {
				//phoneUS: true,
				//digits: true,
				minlength: 10,
				phoneNum: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"start_date": {
				required: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"end_date": {
				normalizer: function (value) {
					return $.trim(value);
				},
				greaterThan: "form[name='frmUpdateContact'],input[name='start_date']"
			},
			"template_id": {
				required: true
			}

		},
		submitHandler: function (form) {
			console.log("update/clone contact form formsubmitted");
			console.log($(form).attr('id'));
			let id = Number($("form[name='frmUpdateContact']").find("input[name='id']").val());
			$(form).find("button[type='submit']").prop('disabled', true);
			$(form).find("button[type='submit']").html("Please wait...");
			let url = '';
			let user_msg = '';

			if (id === 0) {
				url = APP_SITE_URL + 'ajax/add_contact.php';
				user_msg = "Contact added successfully.";
			} else {
				url = APP_SITE_URL + 'ajax/update_contact.php';
				user_msg = "Contact updated successfully.";
			}
			$.ajax({
				url: url,
				type: 'POST',
				dataType: 'json',
				data: $(form).serialize(),
				cache: false
			})
				.done(function (data, textStatus, jQxhr) {
					console.log('ajaxsucess', data);
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");
					if (data.error == true) {
						swal("Alert!", data.msg, "error");
					} else {
						//swal('Success!', user_msg , "success");
						swal({ title: 'Success!', icon: "success", text: user_msg, timer: 1200 });
						contactTable.ajax.reload();
						//$("form[name='addcountry_frm']")[0].reset();
						//var instance = new $.fn.dataTable.Api( '#countryTable' );
						//instance.ajax.reload();
						$('#contactModal').modal('hide');
					}
				})
				.fail(function (jqXhr, textStatus, errorThrown) {
					console.log('fail', 'message:', textStatus);
					swal("Alert!", textStatus, "error");
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");

				});

			return false;
		}
	});

	/** START: CONTACT EDIT */
	$('#contactTable').on('click', '.editLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		$("form[name='frmUpdateContact']").find("input[name='id']").val(id);
		$("form[name='frmUpdateContact']").find("input[name='first_name']").val($(this).data('first_name'));
		$("form[name='frmUpdateContact']").find("input[name='last_name']").val($(this).data('last_name'));
		$("form[name='frmUpdateContact']").find("input[name='email']").val($(this).data('email'));
		$("form[name='frmUpdateContact']").find("input[name='phone']").val($(this).data('phone'));
		$("form[name='frmUpdateContact']").find("input[name='start_date']").val(moment($(this).data('start_date')).format(globalDateFormatForm));
		if($.trim($(this).data('end_date')) != '')
		$("form[name='frmUpdateContact']").find("input[name='end_date']").val(moment($(this).data('end_date')).format(globalDateFormatForm));

		$("form[name='frmUpdateContact']").find("input[name='tags']").val($(this).data('tags'));
		$("form[name='frmUpdateContact']").find("input[name='proximity']").val($(this).data('proximity'));
		$("form[name='frmUpdateContact']").find("input[name='closeness']").val($(this).data('closeness'));

		$("form[name='frmUpdateContact']  select[name='channel'] option[value='" + $(this).data('channel') + "']").prop('selected', true);
		$("form[name='frmUpdateContact']  select[name='send_frequency'] option[value='" + $(this).data('send_frequency') + "']").prop('selected', true);
		$("form[name='frmUpdateContact']  select[name='template_id'] option[value='" + $(this).data('template_id') + "']").prop('selected', true);

		$('#contactModal').modal('show');
		return false;
	});

	/** START: CONTACT Edit / Clone */

	$('#contactTable').on('click', '.cloneLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		let lastname = $.trim($(this).data('last_name')) || '';

		$("form[name='frmUpdateContact']").find("input[name='id']").val(0);
		$("form[name='frmUpdateContact']").find("input[name='first_name']").val($(this).data('first_name'));
		$("form[name='frmUpdateContact']").find("input[name='last_name']").val(lastname);
		//$("form[name='frmUpdateContact']").find("input[name='email']").val($(this).data('email'));
		//$("form[name='frmUpdateContact']").find("input[name='phone']").val($(this).data('phone'));

		//$("form[name='frmUpdateContact']").find("input[name='start_date']").val($(this).data('start_date'));
		$("form[name='frmUpdateContact']").find("input[name='start_date']").val(moment($(this).data('start_date')).format(globalDateFormatForm));

		if($.trim($(this).data('end_date')) != '')
		$("form[name='frmUpdateContact']").find("input[name='end_date']").val(moment($(this).data('end_date')).format(globalDateFormatForm));

		//$("form[name='frmUpdateContact']").find("input[name='end_date']").val($(this).data('end_date'));
		
		$("form[name='frmUpdateContact']").find("input[name='tags']").val($(this).data('tags'));
		$("form[name='frmUpdateContact']").find("input[name='proximity']").val($(this).data('proximity'));
		$("form[name='frmUpdateContact']").find("input[name='closeness']").val($(this).data('closeness'));

		$("form[name='frmUpdateContact']  select[name='channel'] option[value='" + $(this).data('channel') + "']").prop('selected', true);
		$("form[name='frmUpdateContact']  select[name='send_frequency'] option[value='" + $(this).data('send_frequency') + "']").prop('selected', true);
		$("form[name='frmUpdateContact']  select[name='template_id'] option[value='" + $(this).data('template_id') + "']").prop('selected', true);


		$('#contactModal').modal('show');
		return false;
	});

	$('#contactModal').on('hide.bs.modal', function () {
		$("form[name='frmUpdateContact']").find("input[name='id']").val(0);
		$("form[name='frmUpdateContact']").validate().resetForm();
		$("form[name='frmUpdateContact']")[0].reset();
	});

	$('#contactModal').on('shown.bs.modal', function () {
		if (Number($("form[name='frmUpdateContact']").find("input[name='id']").val()) !== 0)
			$("form[name='frmUpdateContact']").find("input[name='first_name']").focus();
		else
			$("form[name='frmUpdateContact']").find("input[name='email']").focus();

	});

	/** END: CONTACT EDIT / CLONE */

	/** START: CONTACT DETAIL */

	$('#contactTable').on('click', '.detailLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		$("form[name='frmViewContact']").find("input[name='first_name']").val($(this).data('first_name'));
		$("form[name='frmViewContact']").find("input[name='last_name']").val($(this).data('last_name'));
		$("form[name='frmViewContact']").find("input[name='email']").val($(this).data('email'));
		$("form[name='frmViewContact']").find("input[name='phone']").val($(this).data('phone'));
		$("form[name='frmViewContact']").find("input[name='start_date']").val($(this).data('start_date'));
		$("form[name='frmViewContact']").find("input[name='end_date']").val($(this).data('end_date'));
		$("form[name='frmViewContact']").find("input[name='tags']").val($(this).data('tags'));
		$("form[name='frmViewContact']").find("input[name='proximity']").val($(this).data('proximity'));
		$("form[name='frmViewContact']").find("input[name='closeness']").val($(this).data('closeness'));

		$("form[name='frmViewContact']  select[name='channel'] option[value='" + $(this).data('channel') + "']").prop('selected', true);
		$("form[name='frmViewContact']  select[name='send_frequency'] option[value='" + $(this).data('send_frequency') + "']").prop('selected', true);
		$("form[name='frmViewContact']  select[name='template_id'] option[value='" + $(this).data('template_id') + "']").prop('selected', true);

		$('#contactDetailModal').modal('show');
		return false;
	});


	$('#contactTable').on('click', '.delLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');


		swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		})
			.then((willDelete) => {
				if (willDelete) {


					$.ajax({
						url: APP_SITE_URL + 'ajax/' + 'del_contact.php',
						type: 'POST',
						dataType: 'json',
						data: { id: id }
					})
						.done(function (data, textStatus, jQxhr) {
							console.log('ajaxsucess', data);
							swal("Success!", "Contact deleted successfully.", "success");
							contactTable.ajax.reload();

							//var instance = new $.fn.dataTable.Api( '#productTable' );
							//instance.ajax.reload();
						})
						.fail(function (jqXhr, textStatus, errorThrown) {
							console.log('fail', 'message:', textStatus);
							swal("Alert!", textStatus, "error");
						});




					/* 				  swal("Poof! Your imaginary file has been deleted!", {
										icon: "success",
									  });
					 */				 // swal("Success!", "Contact deleted successfully.", "success");

				} else {
					//swal("Your imaginary file is safe!");
				}
			});



		/* swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No, cancel it!",
			dangerMode: false,
		  }, function () {
			new Promise((resolve, reject) => {
				console.log('Initial');
			
				reject('sar');
			}).then(function(data){
				console.log('ajaxsucess', data);
				swal("Success!", "Contact deleted successfully.", "success");
				contactTable.ajax.reload();
				//var instance = new $.fn.dataTable.Api( '#productTable' );
				//instance.ajax.reload();
			}).catch((error) => {
				console.log('fail', 'message:', error);
				swal("Alert!", 'Error', "error");
			});
		}); */
		/* swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			type: "warning",
			showCancelButton: true,
			confirmButtonText: 'Yes, I am sure!',
			cancelButtonText: "No, cancel it!"
		},function() {
			if(true){
					$.ajax({
							url : APP_SITE_URL + 'ajax/' + 'del_contact.php',
							type: 'POST',
							dataType: 'json',
							data: {id: id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "Contact deleted successfully.", "success");
						contactTable.ajax.reload();

						//var instance = new $.fn.dataTable.Api( '#productTable' );
						//instance.ajax.reload();
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
			}
		}); */
		return false;
	});

	/** END: CONTACT DETAIL */

	/** END: CONTACT */


	/** start: document ready */
	$(document).ready(function () {

		if ($('#contactTable').length) {
			contactTable = $('#contactTable').DataTable({
				'responsive': true,
				'pageLength': 10,
				'searching': true,
				'ordering': true,
				'processing': true,
				'serverSide': true,
				'serverMethod': 'post',
				'ajax': {
					'url': APP_SITE_URL + 'ajax/' + 'list_contact.php',
					/*'data': function(data){
							let start_date  = $("form[name='activitysearch_frm']").find("input[name='start_date']").val();
							let end_date  = $("form[name='activitysearch_frm']").find("input[name='end_date']").val();
							let user_id  = $("form[name='activitysearch_frm']").find("select[name='user_id']").val();
							let country_id  = $("form[name='activitysearch_frm']").find("select[name='country_id']").val();
							data.start_date = start_date;
							data.end_date = end_date;
							data.user_id = user_id;
							data.country_id = country_id;
						}*/
				},
				'columns': [
					{ data: 'first_name' },
					{ data: 'email' },
					{ data: 'channel_name' },
					{
						mRender: function (data, type, row) {
							return moment(row.start_date).format(globalDateFormat);
						}
					},
					{ data: 'send_frequency' },
					{ data: 'closeness' },
					//{ data: 'tags' },
					{ data: 'updated_on' },
					{ data: 'status' },
					{ data: 'action' }
				],
				'columnDefs': [
					{
						"targets": [6],
						"visible": false,
						"searchable": false
					},
					{ orderable: false, targets: -1 },
				],
				'order': [[6, "desc"]],
				/*dom: 'Bfrtip',
				buttons: [
					'csv'
				]*/
			});


		}

		if ($('#templateTable').length) {
			templateTable = $('#templateTable').DataTable({
				'responsive': true,
				'pageLength': 10,
				'searching': true,
				'ordering': true,
				'processing': true,
				'serverSide': true,
				'serverMethod': 'post',
				'ajax': {
					'url': APP_SITE_URL + 'ajax/' + 'list_template.php',
				},
				'columns': [
					{ data: 'template_name' },
					{ data: 'subject' },
					{ data: 'type' },
					{ data: 'is_active' },
					{
						mRender: function (data, type, row) {
							return moment(row.updated_on).format(globalDateFormat);
						}
					},
					{ data: 'action' }
				],
				'columnDefs': [
					{ orderable: false, targets: -1 },
				],
				'order': [[4, "desc"]],
				/*dom: 'Bfrtip',
				buttons: [
					'csv'
				]*/

			});
		}


		if ($("#frmAddContact").length) {
			jQuery('input[name = "start_date"],input[name = "end_date"]').datetimepicker({
				timepicker: false,
				format: 'Y-m-d',
				minDate: new Date().toISOString() /* 0 curent date */
			});
		}

		if ($("#outboxFrm").length) {
			jQuery('input[name = "start_date"],input[name = "end_date"]').datetimepicker({
				timepicker: false,
				format: 'Y-m-d'
			});
		}



		$('.submitOutboxFrm').change(function(evt){
			outboxTable.ajax.reload();

		});



		if ($('#outboxTable').length) {
			outboxTable = $('#outboxTable').DataTable({
				'responsive': true,
				'pageLength': 10,
				'searching': true,
				'ordering': true,
				'processing': true,
				'serverSide': true,
				'serverMethod': 'post',
				'ajax': {
					'url': APP_SITE_URL + 'ajax/' + 'outbox.php',
					'data': function(data){
						let start_date  = $("form[name='outboxFrm']").find("input[name='start_date']").val();
						let end_date  = $("form[name='outboxFrm']").find("input[name='end_date']").val();
						let contact_id  = $("form[name='outboxFrm']").find("select[name='contact_id']").val();
						data.start_date = start_date;
						data.end_date = end_date;
						data.contact_id = contact_id;
					}
				},
				'columns': [
					{ data: 'first_name' },
					{ data: 'email' },
					{ data: 'send_via' },
					{
						mRender: function (data, type, row) {
							return moment(row.updated_on).format(globalDateFormat);
						}
					}/*,
					{ data: 'action' }*/
				],
				/*'columnDefs': [
					{ orderable: false, targets: -1 },
				],*/
				'order': [[3, "desc"]],
				/*dom: 'Bfrtip',
				buttons: [
					'csv'
				]*/

			});
		}



	});
	/** end: document ready */





	/** START: TEMPLATE */

	$("#frmTemplate").validate({
		rules: {
			"template_name": {
				required: true,
				alphaPlusSpecial: true,
				// nameChars: true,

				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"subject": {
				// nameChars: true,
				alphaPlusSpecial: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			},
			"content": {
				required: true,
				normalizer: function (value) {
					return $.trim(value);
				}
			}
		},
		submitHandler: function (form) {
			console.log("template form formsubmitted");
			console.log($(form).attr('id'));
			let id = Number($("form[name='frmTemplate']").find("input[name='id']").val());
			$(form).find("button[type='submit']").prop('disabled', true);
			$(form).find("button[type='submit']").html("Please wait...");
			let url = '';
			let user_msg = '';

			if (id === 0) {
				url = APP_SITE_URL + 'ajax/add_template.php';
				user_msg = "Template added successfully.";
			} else {
				url = APP_SITE_URL + 'ajax/update_template.php';
				user_msg = "Template updated successfully.";
			}
			$.ajax({
				url: url,
				type: 'POST',
				dataType: 'json',
				data: $(form).serialize(),
				cache: false
			})
				.done(function (data, textStatus, jQxhr) {
					console.log('ajaxsucess', data);
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");
					if (data.error == true) {
						swal("Alert!", data.msg, "error");
					} else {
						swal({ title: 'Success!', icon: "success", text: user_msg, timer: 1200 });
						if($('#templateTable').length){
							templateTable.ajax.reload();
						}
						if($('#frmAddContact').find("select[name='template_id']")){
							$("select[name='template_id']")
							.append($("<option></option>")
									   .attr("value",  data.data['id'])
									   .text($(form).find('input[name="template_name"]').val()
									   )); 
							$("form[name='frmAddContact']  select[name='template_id'] option[value='" + data.data['id']  + "']").prop('selected', true);
						}

						$('#templateModal').modal('hide');
					}
				})
				.fail(function (jqXhr, textStatus, errorThrown) {
					console.log('fail', 'message:', textStatus);
					swal("Alert!", textStatus, "error");
					$(form).find("button[type='submit']").prop('disabled', false);
					$(form).find("button[type='submit']").html("Submit");

				});

			return false;
		}
	});


	$(document).on('click', '.addTemplate', function (evt) {
		$('#templateModal').modal('show');
	});


	

	/** START: template EDIT */
	$('#templateTable').on('click', '.editLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		let content = $(this).data('content');
		content = atob(content);

		$("form[name='frmTemplate']").find("input[name='id']").val(id);
		$("form[name='frmTemplate']  select[name='type'] option[value='" + $(this).data('type') + "']").prop('selected', true);
		$("form[name='frmTemplate']").find("input[name='template_name']").val($(this).data('template_name'));
		$("form[name='frmTemplate']").find("input[name='subject']").val($(this).data('subject'));
		$("form[name='frmTemplate']").find("textarea[name='content']").val(content);
		$('#templateModal').modal('show');
		return false;
	});

	/** END: template Edit  */


	/** START: template DEL */
	$('#templateTable').on('click', '.delLink', function (evt) {
		evt.preventDefault();
		let id = $(this).data('id');
		swal({
			title: "Are you sure?",
			text: "",
			icon: "warning",
			buttons: true,
			dangerMode: true,
		})
		.then((willDelete) => {
			if (willDelete) {
				$.ajax({
					url: APP_SITE_URL + 'ajax/' + 'del_template.php',
					type: 'POST',
					dataType: 'json',
					data: { id: id }
				})
					.done(function (data, textStatus, jQxhr) {
						console.log('ajaxsucess', data.error);
						if(data.error){
							swal("Alert!", data.msg, "error");
						}
						else{
							swal("Success!", data.msg, "success");
							templateTable.ajax.reload();
						}

					})
					.fail(function (jqXhr, textStatus, errorThrown) {
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
			}
		});
		return false;
	});

	/** END: template DEL  */




	$('#templateModal').on('hide.bs.modal', function () {
		$("form[name='frmTemplate']").find("input[name='id']").val(0);
		$("form[name='frmTemplate']").validate().resetForm();
		$("form[name='frmTemplate']")[0].reset();
	});

	$('#templateModal').on('shown.bs.modal', function () {
		$("form[name='frmTemplate']").find("input[name='template_name']").focus();
	});


	$(document).on('click', '#templatePreviewBtnId', function (evt) {
		evt.preventDefault();
		console.log($(this).closest('form').attr('name'));
		let content = $(this).closest('form').find('textarea[name="content"]').val();
		if ($.trim(content) == '') content = 'No content';
		var left = (screen.width - 800) / 2;
		var top = (screen.height - 800) / 4;
		var win = window.open("", "Template - Preview", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes," +
			" width=800,height=700,top=" + top + ",left=" + left);
		win.document.body.innerHTML = content;
	});

	/* $(document).on('click', '#templateSampleBtnId', function (evt) {
		evt.preventDefault();
		console.log($(this).closest('form').attr('name'));
		let content = $(this).closest('form').find('textarea[name="content"]').val();
		if($.trim(content) == '')content = 'No content';
		var left = (screen.width - 800) / 2;
		var top = (screen.height - 800) / 4;
		var win = window.open("", "Template - Preview", "toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes," + 
			" width=800,height=700,top="+top+",left="+left);
		win.document.body.innerHTML = content;
	}); */



	/** END: TEMPLATE */


 /**** START: SETTINGS */
 $("#frmChangePassword").validate({
	rules: {
		"new_password": {
			required: true,
			minlength: 5,
			normalizer: function (value) {
				return $.trim(value);
			}
		},
		"confirm_password": {
			required: true,
			minlength: 5,
			equalTo: "#new_password",
			normalizer: function (value) {
				return $.trim(value);
			}
		},

	},
	submitHandler: function (form) {
		console.log("change password form formsubmitted");
		console.log($(form).attr('id'));
		$(form).find("button[type='submit']").prop('disabled', true);
		$(form).find("button[type='submit']").html("Please wait...");
		let url = APP_SITE_URL + 'ajax/change_password.php';
		$.ajax({
			url: url,
			type: 'POST',
			dataType: 'json',
			data: $(form).serialize(),
			cache: false
		})
			.done(function (data, textStatus, jQxhr) {
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled', false);
				$(form).find("button[type='submit']").html("Submit");
				if (data.error == true) {
					swal("Alert!", data.msg, "error");
				} else {
					$("form[name='frmChangePassword']")[0].reset();
					
					swal({ title: 'Success!', icon: "success", text: 'Password changed successfully.', timer: 1000 });

				}
			})
			.fail(function (jqXhr, textStatus, errorThrown) {
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled', false);
				$(form).find("button[type='submit']").html("Submit");

			});

		return false;
	}
});


$("#frmChangeEmail").validate({
	rules: {
		"email": {
			required: true,
			email: true,
			normalizer: function (value) {
				return $.trim(value);
			}
		}
	},
	submitHandler: function (form) {
		console.log("change email form formsubmitted");
		console.log($(form).attr('id'));
		$(form).find("button[type='submit']").prop('disabled', true);
		$(form).find("button[type='submit']").html("Please wait...");
		let url = APP_SITE_URL + 'ajax/change_email.php';
		$.ajax({
			url: url,
			type: 'POST',
			dataType: 'json',
			data: $(form).serialize(),
			cache: false
		})
			.done(function (data, textStatus, jQxhr) {
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled', false);
				$(form).find("button[type='submit']").html("Submit");
				if (data.error == true) {
					swal("Alert!", data.msg, "error");
				} else {
					$("form[name='frmChangeEmail']")[0].reset();
					
					swal({ title: 'Success!', icon: "success", text: 'Email changed successfully.', timer: 1000 });

				}
			})
			.fail(function (jqXhr, textStatus, errorThrown) {
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled', false);
				$(form).find("button[type='submit']").html("Submit");

			});

		return false;
	}
});




 /**** END: SETTINGS */


})();

