(function () {
	"use strict";

	let contactTable;
	var treeviewMenu = $('.app-menu');

	// Toggle Sidebar
	$('[data-toggle="sidebar"]').click(function(event) {
		event.preventDefault();
		$('.app').toggleClass('sidenav-toggled');
	});

	// Activate sidebar treeview toggle
	$("[data-toggle='treeview']").click(function(event) {
		event.preventDefault();
		if(!$(this).parent().hasClass('is-expanded')) {
			treeviewMenu.find("[data-toggle='treeview']").parent().removeClass('is-expanded');
		}
		$(this).parent().toggleClass('is-expanded');
	});

	// Set initial active toggle
	$("[data-toggle='treeview.'].is-expanded").parent().toggleClass('is-expanded');

	//Activate bootstrip tooltips
	$("[data-toggle='tooltip']").tooltip();

	$(function() {
		$.validator.addMethod("nameChars", function(value, element) {
		  return this.optional(element) || /^[a-z0-9\-_'\s]+$/i.test(value);
		}, "Field must contain only letter, numbers, underscores or dashes");

		$.validator.addMethod("phoneNum", function(value, element) {
			return this.optional(element) || /^\+\d{10,}$/i.test(value);
		  }, "Phone Number should have below pattern: +17879798797");
  

	});
	

	$("#frmAddContact").validate({
		rules:{
			"first_name":{
				required: true,
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"last_name":{
				nameChars:true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"email":{
				required: true,
				email: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"phone":{
				//phoneUS: true,
				//digits: true,
				minlength: 10,
				phoneNum: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"start_date":{
				required: true,
				normalizer: function(value) {
					return $.trim(value);
				}
			},
			"end_date": {
				normalizer: function(value) {
					return $.trim(value);
				}
			}


		},
		submitHandler: function(form){
			console.log("add contact form formsubmitted");
			console.log($(form).attr('id'));
			//let background_img = $('#frmAddContact').find('select[name="background_img"]').val();
			$(form).find("button[type='submit']").prop('disabled',true);
			$(form).find("button[type='submit']").html("Please wait..." );
			$.ajax({
					url : APP_SITE_URL + 'ajax/add_contact.php',
					type: 'POST',
					dataType: 'json',
					data: $(form).serialize(),
					cache:false
			})
			.done(function( data, textStatus, jQxhr ){
				console.log('ajaxsucess', data);
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );
				if(data.error == true){
					swal("Alert!", data.msg, "error");
				}else{
					swal('Success!', 'Contact added successfully.' , "success");
					contactTable.ajax.reload();

				}
			})
			.fail(function( jqXhr, textStatus, errorThrown ){
				console.log('fail', 'message:', textStatus);
				swal("Alert!", textStatus, "error");
				$(form).find("button[type='submit']").prop('disabled',false);
				$(form).find("button[type='submit']").html("Submit" );

			});
			
			return false;
		}
	});

	/**** START: contact */


	$('#contactTable').on('click', '.editLink', function (evt) {
		evt.preventDefault();
		let product_id = $(this).data('productid');
		$("form[name='addproduct_frm']").find("input[name='product_id']").val(product_id);
		$("form[name='addproduct_frm']").find("input[name='product_name']").val($(this).data('name'));
		$("form[name='addproduct_frm']  select[name='country_id'] option[value='" + $(this).data('countryid')  + "']").prop('selected', true);
		$("form[name='addproduct_frm']  select[name='is_active'] option[value='" + $(this).data('isactive')  + "']").prop('selected', true);
		$('#productAddModal').modal('show');
	return false;
	});

	$('#contactTable').on('click', '.delLink', function (evt) {
			evt.preventDefault();
			let product_id = $(this).data('productid');
			swal({
				title: "Are you sure ??",
				text: "", 
				icon: "warning",
				buttons: true,
				dangerMode: true
			})
			.then((willDelete) => {
				if (willDelete) {
					$.ajax({
							url : SITE_URL + 'ajax/del_product.php',
							type: 'POST',
							dataType: 'json',
							data: {product_id: product_id}
					})
					.done(function( data, textStatus, jQxhr ){
						console.log('ajaxsucess', data);
						swal("Success!", "Product deleted successfully.", "success");
						var instance = new $.fn.dataTable.Api( '#productTable' );
						instance.ajax.reload();
					})
					.fail(function( jqXhr, textStatus, errorThrown ){
						console.log('fail', 'message:', textStatus);
						swal("Alert!", textStatus, "error");
					});
				} else {
					//swal("Your imaginary file is safe!");
				}
			});
			return false;
	});

	$(document).ready(function(){

		contactTable = $('#contactTable').DataTable({
			'responsive': true,
			'pageLength': 10,
			'searching': true,
			'ordering': true,
			'processing': true,
			'serverSide': true,
			'serverMethod': 'post',
			'ajax': {
				'url': APP_SITE_URL + 'ajax/' +  'list_contact.php',
				/*'data': function(data){
						let start_date  = $("form[name='activitysearch_frm']").find("input[name='start_date']").val();
						let end_date  = $("form[name='activitysearch_frm']").find("input[name='end_date']").val();
						let user_id  = $("form[name='activitysearch_frm']").find("select[name='user_id']").val();
						let country_id  = $("form[name='activitysearch_frm']").find("select[name='country_id']").val();
						data.start_date = start_date;
						data.end_date = end_date;
						data.user_id = user_id;
						data.country_id = country_id;
					}*/
			},
			'columns': [
				{ data: 'first_name' },
				{ data: 'email' },
				{ data: 'channel_name' },
				{ mRender: function (data, type, row) {
					return moment(row.start_date).format(globalDateFormat); 
					}
				},
				{ data: 'send_frequency' },
				{ data: 'closeness' },
				//{ data: 'tags' },
				{ data: 'updated_on' },
				{ data: 'status' },
				{data: 'action'}
			],
			'columnDefs': [
				{
					"targets": [ 6 ],
					"visible": false,
					"searchable": false
				},
				{ orderable: false, targets: -1 },
			],
			'order': [[ 6, "desc" ]],
			/*dom: 'Bfrtip',
			buttons: [
				'csv'
			]*/
		});

		if(("#frmAddContact").length){
			jQuery('input[name = "start_date"],input[name = "end_date"]').datetimepicker({
				timepicker:false,
				format:'Y-m-d'
			});
		}
	
	});



	/* $('#productAddModal').on('hide.bs.modal', function (){
		$("form[name='addproduct_frm']").find("input[name='product_id']").val(0);
		$("form[name='addproduct_frm']").validate().resetForm();
		$("form[name='addproduct_frm']")[0].reset();
		
	}); */

	/** END: CONTACT */





})();

