<?php
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $model->getUserIdFromEmail($postData['email']);
if($user_id > 0){
    ob_start();
    include_once('./templates/emails/mail-reset-password.php');
    $mail_contents = ob_get_contents();
    ob_end_clean();
    //echo $mail_contents;exit;
    sendEmail($postData['email'],$PAGE_TITLE . ' - Reset Password ' ,$mail_contents,array('reply_to' => FROM_EMAIL));
    $_SESSION['autosender']['err_msg'] = "Please check your inbox to reset your password.";
    header('Location: ../forgot-password.php');
}else{
    $_SESSION['autosender']['err_msg'] = "Entered Email not exists.";
    header('Location: ../forgot-password.php');
}

?>