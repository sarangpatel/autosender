<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

//print_r($_SESSION);exit;
if( !( isset($_SESSION['autosender']['user']) && ($_SESSION['autosender']['user']['id'] > 0) ) ){
    $_SESSION['autosender']['err_msg'] = 'Unauthorized';
   header('Location: ../login.php');
}

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];



$stripeCheckoutURl = getStripePaymentURL($user_id, $model);
header("HTTP/1.1 303 See Other");
header("Location: " . $stripeCheckoutURl);
exit;

?>