<?php

// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
require_once './stripe-sdk/vendor/autoload.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

// This is your test secret API key.
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

//header('Content-Type: application/json');

$session = \Stripe\Checkout\Session::create([
    'line_items' => [[
      'price_data' => [
        'currency' => 'usd',
        'product_data' => [
          'name' => 'T-shirt',
        ],
        'unit_amount' => 2000,
      ],
      'quantity' => 1,
    ]],
    'mode' => 'payment',
    'success_url' => 'https://example.com/success',
    'cancel_url' => 'https://example.com/cancel',
  ]);


$checkout_session = \Stripe\Checkout\Session::create([
    'line_items' => [
        ['price_data' => [
                'currency' => 'usd',
                'product_data' => [
                    'name' => 'T-shirt',
                    'description' => 'description',
                    'images' => [
                        'https://assets.adidas.com/images/h_840,f_auto,q_auto:sensitive,fl_lossy,c_fill,g_auto/c678375652b24f36901bad8c011d2339_9366/Fassona_1.0_Shoes_Blue_EW2637_01_standard.jpg'
                    ]
                ],
                'unit_amount' => 2000,
            ],
            'quantity' => 1,
        ]
    ],
    'mode' => 'payment',
    'success_url' => SITE_URL. '/success.html',
    'cancel_url' => SITE_URL . '/cancel.html',
]);

header("HTTP/1.1 303 See Other");
header("Location: " . $checkout_session->url);