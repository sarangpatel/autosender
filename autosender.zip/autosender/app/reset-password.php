<?php
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $model->isUserIdExists($postData['user_id']);
if($user_id){
    $model->updatePassword($postData['user_id'], $postData['password']);
    $_SESSION['autosender']['err_msg'] = "Password reset successfully.";
    header('Location: ../login.php');
}else{
    $_SESSION['autosender']['err_msg'] = "Link not valid.";
    header('Location: ../reset-password.php');
}

?>