<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
if( !( isset($_SESSION['autosender']['user']) && ($_SESSION['autosender']['user']['id'] > 0) ) ){
    $_SESSION['autosender']['err_msg'] = 'Unauthorized';
   header('Location: ../login.php');
}


$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];
$model->updateData('users', ' plan_id = ?, payment_status = ? where id = ? ',   [1, 'paid', $user_id]);
header('Location: settings.php');
?> 