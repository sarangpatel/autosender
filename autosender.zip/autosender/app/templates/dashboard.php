<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="description" content="BioLab Rx.">
		<title><?php echo $PAGE_TITLE;?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Font-icon css-->
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<!-- Main CSS-->
		<link rel="stylesheet" type="text/css" href="<?php echo APP_SITE_URL; ?>css/main.css">
		<!--<link href="<?php echo APP_SITE_URL; ?>css/datatables.min.css" rel="stylesheet">-->
		<link href="<?php echo APP_SITE_URL; ?>css/jquery.datetimepicker.css" rel="stylesheet">

	</head>
	<body class="app sidebar-mini">
		<!-- Navbar-->
		<header class="app-header">
			<a class="app-header__logo" href="#"><img src = "../assets/images/logo/logo.svg" class = "logo-align"  style  = "background-color:#2a58ff;width:50%" /></a>
			<!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
			<!-- Navbar Right Menu-->
			<ul class="app-nav">
				<li class="app-search header-welcome-msg">Welcome <?php echo $_SESSION['autosender']['user']['full_name']; ?></li>
				<!-- User Menu-->
				<li class="dropdown">
					<a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
					<ul class="dropdown-menu settings-menu dropdown-menu-right">
						<!--<li><a class="dropdown-item" href="page-user.html"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
							<li><a class="dropdown-item" href="page-user.html"><i class="fa fa-user fa-lg"></i> Profile</a></li>-->
							<!-- logout.php -->
						<li><a class="dropdown-item signout" href = "logout.php" ><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</header>
		<!-- Sidebar menu-->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
		<aside class="app-sidebar">
			<ul class="app-menu">
				<li><a class="app-menu__item active" href="#" ><i class="app-menu__icon fa fa-address-book"></i><span class="app-menu__label">Add Contact</span></a></li>

<!-- 				<li class="treeview is-expanded">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-address-book"></i><span class="app-menu__label">Contacts</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item active" href="#" ><i class="app-menu__icon fa fa  fa-plus"></i><span class="app-menu__label">Add Contact</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa fa-list"></i><span class="app-menu__label">List Contacts</span></a></li>
					</ul>
				</li>
 -->				<li class="treeview">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-file"></i><span class="app-menu__label">Email Templates</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item" href="#" ><i class="app-menu__icon fa fa  fa-plus"></i><span class="app-menu__label">Add Template</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa fa-list"></i><span class="app-menu__label">List Template</span></a></li>
					</ul>
				</li>
				<li class="treeview ">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-mobile"></i><span class="app-menu__label">SMS Templates</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item" href="#" ><i class="app-menu__icon fa fa  fa-plus"></i><span class="app-menu__label">Add Template</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa fa-list"></i><span class="app-menu__label">List Template</span></a></li>
					</ul>
				</li>

				<li class="treeview ">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-bolt "></i><span class="app-menu__label">Settings</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item" href="dashboard.php" ><i class="app-menu__icon fa fa-cc-stripe"></i><span class="app-menu__label">Subscription</span></a></li>
						<li><a class="app-menu__item " href="list-smart-pages.php" ><i class="app-menu__icon fa fa-user-circle"></i><span class="app-menu__label">Profile</span></a></li>
					</ul>
				</li>

			</ul>

		</aside>
		<main class="app-content">
			<div class="app-title">
				<div>
					<h1>Add Contact</h1>
				</div>
			</div>
			<div class="row">

				<div class="col-md-3">
						<form id = "frmAddContact" name = "frmAddContact" >
							<div class="tile">
									<h4>Add Contact</h4><hr />
									<div class="row">
										<div class="col-lg-12">
												<div class = "row">
												<div class="form-group col-md-6">
													<label for="exampleInputEmail1">First Name <span class = "mandatory">*</span></label>
													<input class="form-control"  name =  "first_name" type="text" >
												</div>

												<div class="form-group col-md-6">
													<label for="exampleInputEmail1"> Last Name </label>
													<input class="form-control"  name = "last_name" type="text" >
												</div>
												</div>

												<div class="form-group">
													<label for="exampleInputEmail1"> Channel <span class = "mandatory">*</span> </label>
													<select class="form-control"  name = "channel">
															<?php foreach($channels as $channel){ ?>
															<option value = "<?php echo $channel['id']; ?>"><?php echo ucwords($channel['channel_name']); ?></option>
															<?php } ?>
													</select>
													<small class="form-text text-muted" >Specifies connect contact via email, sms, etc</small>

												</div>
												<div class = "row">

												<div class="form-group col-md-6"">
													<label for="exampleInputPassword1">Contact Email <span class = "mandatory">*</span></label>
													<input class="form-control"  name = "email" type="text" >
												</div>
												<div class="form-group col-md-6"">
													<label for="exampleInputPassword1">Contact Phone </label>
													<input class="form-control"  name = "phone" type="text" >
												</div>
												</div>
												<div class = "row">

													<div class="form-group col-md-6">
														<label for="exampleInputPassword1">Start Date <span class = "mandatory">*</span></label>
														<input class="form-control"  name = "start_date" type="text" autocomplete="off" readonly	>
														<small class="form-text text-muted" >When to start sending messages.</small>
													</div>

													<div class="form-group col-md-6">
														<label for="exampleInputPassword1">End Date </label>
														<input class="form-control"  name = "end_date" type="text" autocomplete="off" pattern="\d{4}-\d{2}-\d{2}">
														<small class="form-text text-muted" >When to stop sending messages.</small>

													</div>
												</div>
												<div class="form-group">
													<label for="exampleInputEmail1"> Frequency <span class = "mandatory">*</span> </label>
													<select class="form-control"  name = "send_frequency">
															<option value = "7d">Weekly</option>
															<option value = "30d">Monthly</option>
															<option value = "15d">Twice per Month ( ie every 15 days )</option>
															<option value = "365d">Annually</option>
													</select>
													<small class="form-text text-muted" >Frequency to send autosend messages.</small>

												</div>

												<div class="form-group">
													<label for="exampleInputPassword1">Select Message <span class = "mandatory">*</span></label>
													<select class="form-control" name = "template_id">
													<?php foreach($templates as $templatetype => $template){ ?>
														<optgroup label="<?php echo ucwords($templatetype); ?>" >
														<?php foreach($template as $tv){ ?>
															<option value="<?php echo $tv['id']; ?>"><?php echo $tv['template_name']; ?></option>
														<?php }} ?>
														</optgroup>
													</select>
													<small class="form-text text-muted" >Message to send </small>
												</div>

												<div class = "row">

													<div class="form-group col-md-6">
														<label for="exampleInputPassword1">Proximity </label>
														<input class="form-control"  name = "proximity" type="text" >
													</div>

													<div class="form-group col-md-6">
														<label for="exampleInputPassword1">Closeness</label>
														<input class="form-control"  name = "closeness" type="text" >
													</div>

												</div>
												<div class="form-group">
													<label for="exampleInputPassword1">Tags</label>
													<input class="form-control"  name = "tags" type="text" >
													<small class="form-text text-muted" >Ex: friends, family</small>
												</div>

										</div>
									</div>
										<div class="tile-footer">
										<button class="btn btn-primary" type="submit">Submit</button>
									</div>
							</div>
						</form>

				</div>
				<div class="col-md-9">
					<div class="tile">
						<div class="tile-body">
							<h4>Contacts</h4>
							<!--<small class="form-text mt-2"  style = "font-size: 0.8rem;">*Once Campaign completed, report will be sent on your email address.</small> -->
							<hr />
							<div class="table-responsive">
								<table class="table table-hover table-bordered table-sm " id="contactTable">
									<thead>
										<tr>
											<th>Contact Name</th>
											<th>Contact</th>
											<th>Channel</th>
											<th>StartDate</th>
											<th>Frequency</th>
											<th>Closeness</th>
											<!-- <th>Tags</th> -->
											<th>Updated on</th>
											<th>Status</th>
											<th></th>
										</tr>

										<!--<tr>
											<td>Sarang Patel</td>
											<td>Email</td>
											<td>25 Dec 2021</td>
											<td > - </td>
											<td>Weekly</td>
											<td>25 Dec 2021 11:00 AM</td>
											<td>Active</td>
											<td>
												<a href= "#" class = "btn btn-sm btn-info" >Detail</a>
												<a href= "#" class = "btn btn-sm btn-primary" >Edit</a>

												<a href= "#" class = "btn btn-sm btn-danger" >Delete</a>&nbsp;
												<a href= "#" class = "btn btn-sm btn-success mt-1" >Clone</a>

											</td>
											
										</tr>-->

									</thead>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

		</main>


		<div class="modal fade" id="contactModal" role="dialog" tabindex="-1">
			  <div class="modal-dialog">
				<div class="modal-content">
				<form accept-charset="utf-8" name = "frmUpdateContact" id  = "frmUpdateContact">
					  <input type ="hidden" name = "id" value = "0">
					  <input type = "hidden" name = "user_id" value = "<?php echo $_SESSION['autosender']['user']['id']; ?>"  />
				  
					  <div class="modal-header">
						<h5 class="modal-title">Edit / Clone Contact</h5>
						<!--<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>-->

						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>

					  </div>
					  <div class="modal-body text-start">
						<div class="row">
								<div class="col-lg-12">
										<div class = "row">
										<div class="form-group col-md-6">
											<label for="exampleInputEmail1">First Name <span class = "mandatory">*</span></label>
											<input class="form-control"  name =  "first_name" type="text" >
										</div>

										<div class="form-group col-md-6">
											<label for="exampleInputEmail1"> Last Name </label>
											<input class="form-control"  name = "last_name" type="text" >
										</div>
										</div>

										<div class="form-group">
											<label for="exampleInputEmail1"> Channel <span class = "mandatory">*</span> </label>
											<select class="form-control"  name = "channel">
													<?php foreach($channels as $channel){ ?>
													<option value = "<?php echo $channel['id']; ?>"><?php echo ucwords($channel['channel_name']); ?></option>
													<?php } ?>
											</select>
											<small class="form-text text-muted" >Specifies connect contact via email, sms, etc</small>

										</div>
										<div class = "row">

										<div class="form-group col-md-6"">
											<label for="exampleInputPassword1">Contact Email <span class = "mandatory">*</span></label>
											<input class="form-control"  name = "email" type="text" >
										</div>
										<div class="form-group col-md-6"">
											<label for="exampleInputPassword1">Contact Phone </label>
											<input class="form-control"  name = "phone" type="text" >
										</div>
										</div>
										<div class = "row">

											<div class="form-group col-md-6">
												<label for="exampleInputPassword1">Start Date <span class = "mandatory">*</span></label>
												<input class="form-control"  name = "start_date" type="text" autocomplete="off" readonly	>
												<small class="form-text text-muted" >When to start sending messages.</small>
											</div>

											<div class="form-group col-md-6">
												<label for="exampleInputPassword1">End Date </label>
												<input class="form-control"  name = "end_date" type="text" autocomplete="off" pattern="\d{4}-\d{2}-\d{2}">
												<small class="form-text text-muted" >When to stop sending messages.</small>

											</div>
										</div>
										<div class="form-group">
											<label for="exampleInputEmail1"> Frequency <span class = "mandatory">*</span> </label>
											<select class="form-control"  name = "send_frequency">
													<option value = "7d">Weekly</option>
													<option value = "30d">Monthly</option>
													<option value = "15d">Twice per Month ( ie every 15 days )</option>
													<option value = "365d">Annually</option>
											</select>
											<small class="form-text text-muted" >Frequency to send autosend messages.</small>

										</div>

										<div class="form-group">
											<label for="exampleInputPassword1">Select Message <span class = "mandatory">*</span></label>
											<select class="form-control" name = "template_id">
											<?php foreach($templates as $templatetype => $template){ ?>
												<optgroup label="<?php echo ucwords($templatetype); ?>" >
												<?php foreach($template as $tv){ ?>
													<option value="<?php echo $tv['id']; ?>"><?php echo $tv['template_name']; ?></option>
												<?php }} ?>
												</optgroup>
											</select>
											<small class="form-text text-muted" >Message to send </small>
										</div>

										<div class = "row">

											<div class="form-group col-md-6">
												<label for="exampleInputPassword1">Proximity </label>
												<input class="form-control"  name = "proximity" type="text" >
											</div>

											<div class="form-group col-md-6">
												<label for="exampleInputPassword1">Closeness</label>
												<input class="form-control"  name = "closeness" type="text" >
											</div>

										</div>
										<div class="form-group">
											<label for="exampleInputPassword1">Tags</label>
											<input class="form-control"  name = "tags" type="text" >
											<small class="form-text text-muted" >Ex: friends, family</small>
										</div>

								</div>
						</div>
					  </div>
					  <div class="modal-footer">
						<button type="submit" class="btn btn-primary" >Submit</button>
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					  </div>
				</form>
				</div>
			  </div>
			</div>

		<!-- overlay -->
		<div class="overlay">
			<div class="overlay__inner">
			    <div class="overlay__content"><span class="spinner"></span></div>
			</div>
		</div>
		<!-- overlay -->

		<!-- Essential javascripts for application to work-->
		<script src="<?php echo APP_SITE_URL; ?>js/config.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/jquery-3.3.1.min.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/popper.min.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/moment.min.js"></script>
		<!-- <script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/sweetalert.min.js"></script> -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

		<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
		<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

		<script src="<?php echo APP_SITE_URL; ?>js/jquery.datetimepicker.full.min.js"></script>
		<!--<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>-->

		<script src="<?php echo APP_SITE_URL; ?>js/main.js"></script>
		<!-- Data table plugin-->
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/dataTables.bootstrap.min.js"></script>
		<!-- Data table plugin-->

		<!-- The javascript plugin to display page loading on top-->
		<script src="<?php echo APP_SITE_URL; ?>js/plugins/pace.min.js"></script>
		<!-- Page specific javascripts-->

	


	</body>
</html>