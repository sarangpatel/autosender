<!DOCTYPE html>
<html lang="en">
	<head>
		<meta name="description" content="BioLab Rx.">
		<title><?php echo $PAGE_TITLE;?></title>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Font-icon css-->
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<!-- Main CSS-->
		<link rel="stylesheet" type="text/css" href="<?php echo APP_SITE_URL; ?>css/main.css">
		<!--<link href="<?php echo APP_SITE_URL; ?>css/datatables.min.css" rel="stylesheet">-->
		<link href="<?php echo APP_SITE_URL; ?>css/jquery.datetimepicker.css" rel="stylesheet">

	</head>
	<body class="app sidebar-mini">
		<!-- Navbar-->
		<header class="app-header">
			<a class="app-header__logo" href="#"><img src = "../assets/images/logo/logo.svg" class = "logo-align"  style  = "background-color:#2a58ff;width:50%" /></a>
			<!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
			<!-- Navbar Right Menu-->
			<ul class="app-nav">
				<li class="app-search header-welcome-msg">Welcome <?php echo $_SESSION['autosender']['user']['full_name']; ?></li>
				<!-- User Menu-->
				<li class="dropdown">
					<a class="app-nav__item" href="#" data-toggle="dropdown" aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
					<ul class="dropdown-menu settings-menu dropdown-menu-right">
						<!--<li><a class="dropdown-item" href="page-user.html"><i class="fa fa-cog fa-lg"></i> Settings</a></li>
							<li><a class="dropdown-item" href="page-user.html"><i class="fa fa-user fa-lg"></i> Profile</a></li>-->
							<!-- logout.php -->
						<li><a class="dropdown-item signout" href = "logout.php" ><i class="fa fa-sign-out fa-lg"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</header>
		<!-- Sidebar menu-->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
		<aside class="app-sidebar">
			<ul class="app-menu">
                <li><a class="app-menu__item" href="dashboard.php" ><i class="app-menu__icon fa fa-address-book"></i><span class="app-menu__label">Contact</span></a></li>

<!-- 				<li class="treeview is-expanded">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-address-book"></i><span class="app-menu__label">Contacts</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item active" href="#" ><i class="app-menu__icon fa fa  fa-plus"></i><span class="app-menu__label">Add Contact</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa fa-list"></i><span class="app-menu__label">List Contacts</span></a></li>
					</ul>
				</li>
 -->			<li>
                     <a class="app-menu__item active" href="templates.php" ><i class="app-menu__icon fa fa-file"></i><span class="app-menu__label">Templates</span></a>
				</li>
				<!-- <li class="treeview ">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-mobile"></i><span class="app-menu__label">SMS Templates</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item" href="#" ><i class="app-menu__icon fa fa  fa-plus"></i><span class="app-menu__label">Add Template</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa fa-list"></i><span class="app-menu__label">List Template</span></a></li>
					</ul>
				</li> -->

				<li class="treeview ">
					<a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-bolt "></i><span class="app-menu__label">Settings</span><i class="treeview-indicator fa fa-angle-right"></i></a>
					<ul class="treeview-menu">
						<li><a class="app-menu__item" href="#" ><i class="app-menu__icon fa fa-cc-stripe"></i><span class="app-menu__label">Subscription</span></a></li>
						<li><a class="app-menu__item " href="#" ><i class="app-menu__icon fa fa-user-circle"></i><span class="app-menu__label">Profile</span></a></li>
					</ul>
				</li>

			</ul>

		</aside>
		<main class="app-content">
			<div class="app-title">
				<div>
					<h1>Templates</h1>
				</div>
			</div>
			<div class="row">

				<div class="col-md-12">
					<div class="tile">
						<div class="tile-body">
							<h4>Templates</h4>

							<hr />
                            <div>
                                <div class="float-right mb-2"><a href = "#" class = "btn btn-primary addTemplate"  >Add Template</a></div>
                            </div>


							<div class="table-responsive">

								<table class="table table-hover table-bordered table-sm " id="templateTable">
									<thead>
										<tr>
											<th>Name</th>
											<th>Subject</th>
											<th>Type</th>
											<th>Status</th>
											<th>Updated on</th>
											<th></th>
										</tr>

									</thead>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>

		</main>

		<!-- START: include modal for edit -->
		<div class="modal fade" id="templateModal" role="dialog" tabindex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
					    <form accept-charset="utf-8" name = "frmTemplate" id  = "frmTemplate">
							<input type ="hidden" name = "id" value = "0">
							<input type = "hidden" name = "user_id" value = "<?php echo $_SESSION['autosender']['user']['id']; ?>"  />
						
							<div class="modal-header">
                                <h5 class="modal-title">Add / Edit Template</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
							</div>
							<div class="modal-body text-start">
                                <div class="row">
                                       <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1"> Type <span class = "mandatory">*</span> </label>
                                                <select class="form-control"  name = "type">
                                                        <option value = "email">Email</option>
                                                        <!-- <option value = "sms">SMS</option>
                                                        <option value = "text">Text</option> -->
                                                </select>
                                                <small class="form-text text-muted" >Specifies template type email,sms or text</small>
                                            </div>
                                            <div class="form-group ">
                                                    <label for="exampleInputEmail1">Template Name <span class = "mandatory">*</span></label>
                                                    <input class="form-control"  name =  "template_name" type="text" >
                                            </div>
                                            <div class="form-group ">
                                                <label for="exampleInputEmail1">Subject</label>
                                                <input class="form-control"  name = "subject" type="text" >
                                            </div>
                                            <div class="form-group ">
                                                <label for="exampleInputEmail1">Content <span class = "mandatory">*</span></label>
                                                <textarea class="form-control"  name = "content" rows  = "10" ></textarea>
                                            </div>
                                            <div>
                                                 <a class="btn btn-primary"  target = "_blank" href = "<?php echo APP_SITE_URL; ?>email-template.txt" >View Sample</a>
                    							<button class="btn btn-primary" type="button" id = "templatePreviewBtnId">Preview</button>
                                            </div>
                                        </div>
                                </div>
							</div>
							<div class="modal-footer">
                                <button type="submit" class="btn btn-primary" >Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							</div>
					</form>
				</div>
			</div>
		</div>
		<!-- END: include modal for edit -->



		<!-- overlay -->
		<div class="overlay">
			<div class="overlay__inner">
			    <div class="overlay__content"><span class="spinner"></span></div>
			</div>
		</div>
		<!-- overlay -->

		<!-- Essential javascripts for application to work-->
		<script src="<?php echo APP_SITE_URL; ?>js/config.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/jquery-3.3.1.min.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/popper.min.js"></script>
		<script src="<?php echo APP_SITE_URL; ?>js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/moment.min.js"></script>
		<!-- <script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/sweetalert.min.js"></script> -->
		<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

		<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
		<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

		<script src="<?php echo APP_SITE_URL; ?>js/jquery.datetimepicker.full.min.js"></script>
		<!--<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>-->

		<script src="<?php echo APP_SITE_URL; ?>js/main.js"></script>
		<!-- Data table plugin-->
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="<?php echo APP_SITE_URL; ?>js/plugins/dataTables.bootstrap.min.js"></script>
		<!-- Data table plugin-->

		<!-- The javascript plugin to display page loading on top-->
		<script src="<?php echo APP_SITE_URL; ?>js/plugins/pace.min.js"></script>
		<!-- Page specific javascripts-->

	


	</body>
</html>