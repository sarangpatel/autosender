<div class="modal fade" id="templateModal" role="dialog" tabindex="-1">
			<div class="modal-dialog">
				<div class="modal-content">
					    <form accept-charset="utf-8" name = "frmTemplate" id  = "frmTemplate">
							<input type ="hidden" name = "id" value = "0">
							<input type = "hidden" name = "user_id" value = "<?php echo $_SESSION['autosender']['user']['id']; ?>"  />
						
							<div class="modal-header">
                                <h5 class="modal-title">Add / Edit Template</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
							</div>
							<div class="modal-body text-start">
                                <div class="row">
                                       <div class="col-lg-12">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1"> Type <span class = "mandatory">*</span> </label>
                                                <select class="form-control"  name = "type">
                                                        <option value = "email">Email</option>
                                                        <!-- <option value = "sms">SMS</option>
                                                        <option value = "text">Text</option> -->
                                                </select>
                                                <small class="form-text text-muted" >Specifies template type email,sms or text</small>
                                            </div>
                                            <div class="form-group ">
                                                    <label for="exampleInputEmail1">Template Name <span class = "mandatory">*</span></label>
                                                    <input class="form-control"  name =  "template_name" type="text" >
                                            </div>
                                            <div class="form-group ">
                                                <label for="exampleInputEmail1">Subject</label>
                                                <input class="form-control"  name = "subject" type="text" >
                                            </div>
                                            <div class="form-group ">
                                                <label for="exampleInputEmail1">Content <span class = "mandatory">*</span></label>
                                                <textarea class="form-control"  name = "content" rows  = "10" ></textarea>
                                            </div>
                                            <div>
                                                 <a class="btn btn-primary"  target = "_blank" href = "<?php echo APP_SITE_URL; ?>email-template.txt" >View Sample</a>
                    							<button class="btn btn-primary" type="button" id = "templatePreviewBtnId">Preview</button>
                                            </div>
                                        </div>
                                </div>
							</div>
							<div class="modal-footer">
                                <button type="submit" class="btn btn-primary" >Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
							</div>
					</form>
				</div>
			</div>
		</div>