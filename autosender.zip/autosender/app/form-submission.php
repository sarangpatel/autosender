<?php
  
// get database connection
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$returnData = array();
$returnData['error'] = false;
$returnData['msg'] = "success";
$month = date('m');
$year = date('Y');
$returnData['data'] = $model->insertData("form_submissions", $postData);
http_response_code(200);
echo sendResponse($returnData);
  
?>