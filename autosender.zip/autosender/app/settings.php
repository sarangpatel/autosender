<?php
include_once './config/core.php';
include_once './config/database.php';
include_once './config/model.php';
if( !( isset($_SESSION['autosender']['user']) && ($_SESSION['autosender']['user']['id'] > 0) ) ){
    $_SESSION['autosender']['err_msg'] = 'Unauthorized';
   header('Location: ../login.php');
}

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];
$usersettings  = $model->getUser($user_id);
include_once './templates/settings.php';
?> 