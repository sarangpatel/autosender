<?php

require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $_SESSION['autosender']['user']['id'];
$values = array();
$values[] = $user_id;
array_walk_recursive($postData, function(&$v) { $v = trim($v); });
$values[] = $postData['template_name']; 
$values[] = empty($postData['subject']) ? NULL: $postData['subject'] ; 
$values[] = $postData['content']; 
$values[] = $postData['type']; 
$values[] = date('Y-m-d H:i:s'); 
$values[] = date('Y-m-d H:i:s'); 

$qryResult = $model->insertData('templates', 'user_id,template_name,subject,content,type,created_on,updated_on', $values);
if(!$qryResult['error']){
    echo json_encode(array('error' => false, 'data' => array('id' => $qryResult['data']['id']) ,  'msg' => 'success'));
}else{
	echo json_encode(array('error' => true, 'msg' => 'Error: Some DB Occured. Please try again.'));
}
exit;
?>