<?php
require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];


## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
//if($columnName == 3)$columnName = 'start_date';
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = trim($_POST['search']['value']); // Search value
$searchQuery = ' ';

## Custom Field value
$starDate = trim($_POST['start_date']);
$endDate = trim($_POST['end_date']);
$contact_id = trim($_POST['contact_id']);


if($starDate != ''){
   $searchQuery .= " and (mq.updated_on >='".$starDate . ' 00:00:00'  . "') ";
}

if($endDate != ''){
   $searchQuery .= " and (mq.updated_on <='".$endDate . ' 23:59:59'  ."')  ";
}

if($contact_id != ''){
   $searchQuery .= " and (mq.contact_id = ". $contact_id . ") ";
}



if($searchValue != ''){
   
  // if(strtolower($searchValue) == 'active')$searchValue = 1;
  //if(strtolower($searchValue) == 'inactive')$searchValue = 0;

   //c.updated_on  like '%".$searchValue."%'
   $searchQuery .= "  and (c.first_name like '%".$searchValue."%' 
      or  c.email like '%".$searchValue."%' 
      or  mq.send_via like '%".$searchValue."%' 
      or  mq.updated_on like '%".$searchValue."%' 

	  )  ";
}
	
## Total number of records without filtering
#$sel = mysqli_query($con,"select count(*) as allcount from employee");
#$records = mysqli_fetch_assoc($sel);
#$totalRecords = $records['allcount'];

$query = "select count(1) as allcount from message_queue where user_id = $user_id and sent = 1;" ;
$stmt = $db->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$totalRecords = $records[0]['allcount'];



## Total number of records with filtering
#$sel = mysqli_query($con,"select count(1) as allcount from employee WHERE 1 ".$searchQuery);
#$records = mysqli_fetch_assoc($sel);
#$totalRecordwithFilter = $records['allcount'];


$query = "select c.user_id, mq.contact_id, c.email, CONCAT(c.first_name, ' ', c.last_name) AS first_name, mq.updated_on, mq.send_via,  mq.sent from message_queue mq inner join contacts c on c.id = mq.contact_id   
   		  where mq.user_id = $user_id  and mq.sent = 1 ".  $searchQuery ;
//echo $query;
$stmt = $db->prepare($query);
$stmt->execute();
$num = $stmt->rowCount();
$totalRecordwithFilter = $num;


## Fetch records
#$empQuery = "select * from employee WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
#$empRecords = mysqli_query($con, $empQuery);

$query = "select c.user_id, mq.contact_id, c.email, CONCAT(c.first_name, ' ', c.last_name) AS first_name, mq.updated_on, mq.send_via,  mq.sent from message_queue mq inner join contacts c on c.id = mq.contact_id   
where mq.user_id = $user_id  and mq.sent = 1 ".  $searchQuery . " order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
//echo $query;

$stmt = $db->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$data = array();
foreach($records as $row){
   $data[] = array(
     "first_name"=>$row['first_name'],
     "email"=>$row['email'],
     "send_via" => $row['send_via'],
     "updated_on" => $row['updated_on']
     //'action' =>  '&nbsp;' 

   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);
echo json_encode($response);

function getActionLinks($row){


	$editAttr = " " ;
	
   $delAttr = " " ; 

/*    $detailLink = "<a href= \"#\" class = \"btn btn-sm btn-info mt-1 mr-1 detailLink\" $editAttr >Detail</a>";
   $cloneLink = "<a href= \"#\" class = \"btn btn-sm btn-success mt-1 mr-1 cloneLink\" $editAttr >Clone</a>";
   $editLink = "<a href= \"#\" class = \"btn btn-sm btn-primary mt-1 mr-1 editLink\" $editAttr >Edit</a>";
   $delLink = "<a href= \"#\" class = \"btn btn-sm btn-danger mt-1 mr-1 delLink \"  $delAttr >Delete</a>";

	return $detailLink . $cloneLink .  $editLink . $delLink;
 */
}


exit;


?>