<?php
require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);
$user_id = $_SESSION['autosender']['user']['id'];


## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = trim($_POST['search']['value']); // Search value
$searchQuery = ' ';

if($searchValue != ''){
   //c.updated_on  like '%".$searchValue."%'
   $searchQuery .= "  and (t.template_name like '%".$searchValue."%' 
      or  t.subject like '%".$searchValue."%' 
      or  t.type like '%".$searchValue."%' 
      or  t.updated_on like '%".$searchValue."%' 
      )  ";
}

$query = "select count(1) as allcount from templates where user_id = $user_id" ;
$stmt = $db->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$totalRecords = $records[0]['allcount'];


$query = "select t.id, t.user_id, t.template_name, t.subject,t.type,t.content, t.is_active, t.created_on, t.updated_on from templates t where t.user_id = $user_id ".  $searchQuery ;
//echo $query;
$stmt = $db->prepare($query);
$stmt->execute();
$num = $stmt->rowCount();
$totalRecordwithFilter = $num;


## Fetch records
#$empQuery = "select * from employee WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
#$empRecords = mysqli_query($con, $empQuery);

$query = "select t.id, t.user_id, t.template_name, t.subject,t.type,t.content, t.is_active, t.created_on, t.updated_on  from templates t  where t.user_id = $user_id " .
          $searchQuery ." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
//echo $query;

$stmt = $db->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$data = array();
foreach($records as $row){
   $data[] = array(
     "template_name"=>$row['template_name'],
     "subject"=>$row['subject'],
     "type"=>$row['type'],
     "is_active" => $row['is_active'] == 1 ? 'Active': 'Inactive',
     "updated_on" => $row['updated_on'],
     'action' => getActionLinks($row)     

   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);
echo json_encode($response);

function getActionLinks($row){

    $content = base64_encode($row['content']);
	$editAttr = " data-id = {$row['id']}  data-userid = {$row['user_id']} data-template_name = '{$row['template_name']}'  data-subject = '{$row['subject']}' 
                 data-type = '{$row['type']}'   data-status = '{$row['is_active']}' data-updated_on = '{$row['updated_on']}' data-content = '$content' " ;
	
   $delAttr = " data-id = {$row['id']} " ; 

   $editLink = "<a href= \"#\" class = \"btn btn-sm btn-primary mt-1 mr-1 editLink\" $editAttr >Edit</a>";
   $delLink = "<a href= \"#\" class = \"btn btn-sm btn-danger mt-1 mr-1 delLink \"  $delAttr >Delete</a>";

	return $editLink . $delLink;
}


exit;


?>