<?php

require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $_SESSION['autosender']['user']['id'];
$id = $postData['id'];
$values = array();
array_walk_recursive($postData, function(&$v) { $v = trim($v); });
$values[] = $postData['template_name']; 
$values[] = empty($postData['subject']) ? NULL: $postData['subject'] ; 
$values[] = $postData['content']; 
$values[] = $postData['type']; 
$values[] = date('Y-m-d H:i:s'); 
$values[] = $id;

$qryResult = $model->updateData('templates', '  template_name = ?, subject = ?, content = ?, type = ?, updated_on = ? where id = ? ', $values);
if(!$qryResult['error']){
    echo json_encode(array('error' => false, 'data' => array('id' => $id) ,  'msg' => 'success'));
}else{
	echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
}
exit;
?>