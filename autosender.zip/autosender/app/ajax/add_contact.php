<?php

require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $_SESSION['autosender']['user']['id'];
$values = array();
$values[] = $user_id;
$values[] = $postData['first_name']; 
$values[] = $postData['last_name']; 
$values[] = $postData['email']; 
$values[] = $postData['phone']; 
$values[] = $postData['start_date']; 
$values[] = $postData['end_date']; 
$values[] = $postData['send_frequency']; 
$values[] = $postData['template_id']; 
$values[] = $postData['proximity']; 
$values[] = $postData['closeness']; 
$values[] = $postData['tags']; 
$values[] = date('Y-m-d H:i:s'); 
$values[] = date('Y-m-d H:i:s'); 

$qryResult = $model->insertData('contacts', 'user_id,first_name,last_name,email,phone,start_date,end_date,
                    send_frequency,template_id,proximity,closeness,tags,created_on,updated_on', $values);
if(!$qryResult['error']){
    echo json_encode(array('error' => false, 'data' => array('id' => $qryResult['data']['id']) ,  'msg' => 'success'));
}else{
	echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
}
exit
?>