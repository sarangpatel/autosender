<?php

require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $_SESSION['autosender']['user']['id'];
$values = array();
$values[] = $user_id;
array_walk_recursive($postData, function(&$v) { $v = trim($v); });
$values[] = $postData['first_name']; 
$values[] = $postData['last_name']; 
$values[] = $postData['email']; 
$values[] = empty($postData['phone']) ? NULL: $postData['phone'] ; 
$values[] = $postData['start_date'] . ' ' . date ('H:i:s'); 
$values[] = $postData['end_date']   . ' ' . date ('H:i:s'); 
$values[] = $postData['send_frequency']; 
$values[] = $postData['template_id']; 
$values[] = $postData['proximity']; 
$values[] = $postData['closeness']; 
$values[] = $postData['tags']; 
$values[] = date('Y-m-d H:i:s'); 
$values[] = date('Y-m-d H:i:s'); 

$qryResult = $model->insertData('contacts', 'user_id,first_name,last_name,email,phone,start_date,end_date,
                    send_frequency,template_id,proximity,closeness,tags,created_on,updated_on', $values);
if(!$qryResult['error']){
    $qryResult = $model->insertData('user_channels', 'user_id,contact_id,channel_id,created_on',[$user_id,
                $qryResult['data']['id'],$postData['channel'],date('Y-m-d H:i:s')]);
    echo json_encode(array('error' => false, 'data' => array('id' => $qryResult['data']['id']) ,  'msg' => 'success'));
}else{
	echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
}
exit;
?>