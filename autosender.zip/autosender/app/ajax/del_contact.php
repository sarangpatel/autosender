<?php
require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
extract($_POST);
if(!empty($id) && $id != 0){
	$qryResult = $model->deleteData('contacts', 'id  = ?,', [$id]);
	if(!$qryResult['error']){
		echo json_encode(array('error' => false, 'data' => array('id' => $id) ,  'msg' => 'success'));
	}else{
		echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
	}
}else{
	echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
}
	exit;
?>