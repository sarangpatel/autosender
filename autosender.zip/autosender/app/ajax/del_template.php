<?php
require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
extract($_POST);
if(!empty($id) && $id != 0){
    $record = $model->getData('contacts', ' template_id = ? ', ' order by id asc limit 1 ', [$id]);
    if(count($record) > 0){
        echo json_encode(array('error' => true, 'msg' => 'This template mapped with Contact Name "' . $record[0]['first_name']. '". Please unmap Template ID first.' ));
    }else{
        $qryResult = $model->deleteData('templates', 'id  = ?,', [$id]);
        if(!$qryResult['error']){
            echo json_encode(array('error' => false, 'data' => array('id' => $id) ,  'msg' => 'Template deleted successfully.'));
        }else{
            echo json_encode(array('error' => true, 'msg' => 'Error: DB Error occured, please try again..'));
        }
    }
}else{
	echo json_encode(array('error' => true, 'msg' => 'ID not valid.'));
}
exit;
?>