<?php

require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();

$model = new Model($db);
$postData = $_POST;
$user_id = $_SESSION['autosender']['user']['id'];
$values = array();
array_walk_recursive($postData, function(&$v) { $v = trim($v); });
$values[] = md5($postData['new_password']); 
$values[] = date('Y-m-d H:i:s'); 
$values[] = $user_id;
$qryResult = $model->updateData('users', '  password = ?, updated_on = ? where id = ? ', $values);
if(!$qryResult['error']){
    echo json_encode(array('error' => false,   'msg' => 'success'));
}else{
	echo json_encode(array('error' => true, 'msg' => $qryResult['msg']));
}
exit;
?>