<?php
require '../config/core.php';
require '../config/database.php';
require '../config/model.php';

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);


## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = trim($_POST['search']['value']); // Search value
$searchQuery = ' ';

## Custom Field value
/*$starDate = trim($_POST['start_date']);
$endDate = trim($_POST['end_date']);
$countryId = trim($_POST['country_id']);
$userId = trim($_POST['user_id']);


if($starDate != ''){
   $searchQuery .= " and (al.created_on >='".$starDate."') ";
}

if($endDate != ''){
   $searchQuery .= " and (al.created_on <='".$endDate."')  ";
}
if($countryId != ''){
   $searchQuery .= " and (al.country_id=".$countryId.") ";
}

if($userId != ''){
   $searchQuery .= " and (al.created_by =".$userId.") ";
}*/



if($searchValue != ''){
   $searchQuery .= "  and (c.contact_name like '%".$searchValue."%' or 
      c.updated_on  like '%".$searchValue."%'
	  or  channel.channel_name like '%".$searchValue."%' 
	   or  c.start_date like '%".$searchValue."%' 
      or  c.frequency like '%".$searchValue."%' 
      or  c.closeness like '%".$searchValue."%' 
	  or c.tags like '%".$searchValue."%' 
	  )  ";
}
	
## Total number of records without filtering
#$sel = mysqli_query($con,"select count(*) as allcount from employee");
#$records = mysqli_fetch_assoc($sel);
#$totalRecords = $records['allcount'];

$query = "select count(1) as allcount from contacts where user_id = 1" ;
$stmt = $conn->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$totalRecords = $records[0]['allcount'];



## Total number of records with filtering
#$sel = mysqli_query($con,"select count(1) as allcount from employee WHERE 1 ".$searchQuery);
#$records = mysqli_fetch_assoc($sel);
#$totalRecordwithFilter = $records['allcount'];


$query = "select  CONCAT(c.first_name, ' ', c.last_name) AS contact_name, c.email, channel.channel_name,c.start_date,c.frequency,c.closeness,
         c.tags, c.updated_on, c.status c inner join user_channels uc on c.id = uc.contact_id  
		  inner join channels channel channel.id = uc.channel_id where user_id = 1 ".  $searchQuery ;
$stmt = $conn->prepare($query);
$stmt->execute();
$num = $stmt->rowCount();
$totalRecordwithFilter = $num;


## Fetch records
#$empQuery = "select * from employee WHERE 1 ".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
#$empRecords = mysqli_query($con, $empQuery);

$query = "select  CONCAT(c.first_name, ' ', c.last_name) AS contact_name, c.email, channel.channel_name,c.start_date,c.frequency,c.closeness,
c.tags, c.updated_on, c.status from contacts c inner join user_channels uc on c.id = uc.contact_id  
inner join channels channel channel.id = uc.channel_id   where user_id = 1 ".  $searchQuery ." order by ".$columnName." ".$columnSortOrder." limit ".$row.",".$rowperpage;
$stmt = $conn->prepare($query);
$stmt->execute();
$records = $stmt->fetchAll();
$data = array();
foreach($records as $row){
   $data[] = array(
     "contact_name"=>$row['contact_name'],
     "email"=>$row['email'],
     "channel_name"=>$row['channel_name'],
     "start_date"=>$row['start_date'],
     "frequency"=>$row['frequency'],
     "closeness"=>$row['closeness'],
     "tags"=>$row['tags'],
     "updated_on" => $row['updated_on'],
     "status" => $row['updated_on'],
     'action' => getActionLinks($row)     

   );
}

## Response
$response = array(
  "draw" => intval($draw),
  "iTotalRecords" => $totalRecords,
  "iTotalDisplayRecords" => $totalRecordwithFilter,
  "aaData" => $data
);
echo json_encode($response);

function getActionLinks($row){
   return '<a href= "#" class = "btn btn-sm btn-info" >Detail</a>
   <a href= "#" class = "btn btn-sm btn-primary" >Edit</a>

   <a href= "#" class = "btn btn-sm btn-danger" >Delete</a>&nbsp;
   <a href= "#" class = "btn btn-sm btn-success mt-1" >Clone</a>';

//	$editAttr = " data-userid = {$row['id']} data-name = '{$row['name']}'  data-email = '{$row['email']}'  data-mobile = '{$row['mobile']}' data-countryid = {$row['country_id']}  " .
				" data-isactive = '{$row['is_active']}' data-accounttype = '{$row['account_type']}'" ;
	
//	$editLink = "<a href=\"#\" class=\"btn btn-outline-info btn-rounded editLink \"  $editAttr ><i class=\"fas fa-pen\"></i></a>";

	//$delAttr = " data-userid = {$row['id']} " ; 
	//$delLink = "<a href=\"#\" class=\"btn btn-outline-danger btn-rounded delLink\" $delAttr ><i class=\"fas fa-trash\"></i></a>";

	//return $editLink . ' ' . $delLink;
}


exit;


?>