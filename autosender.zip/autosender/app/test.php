<?php
require_once  dirname(__FILE__) . '/config/core.php';
include_once  dirname(__FILE__) . '/config/database.php';
include_once  dirname(__FILE__) . '/config/model.php';
$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

?>