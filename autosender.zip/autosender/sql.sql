ALTER TABLE `message_queue`
ADD `user_id` int NOT NULL DEFAULT '0' AFTER `id`;

ALTER TABLE `message_queue`
ADD INDEX `user_id` (`user_id`);

ALTER TABLE `message_queue`
ADD INDEX `updated_on` (`updated_on` DESC),
DROP INDEX `status`;

ALTER TABLE `message_queue`
ADD INDEX `user_id_sent` (`user_id`, `sent`);