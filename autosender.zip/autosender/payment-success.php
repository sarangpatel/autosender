<?php 
include_once './app/config/core.php';
include_once './app/config/database.php';
include_once './app/config/model.php';
require_once './stripe-sdk/vendor/autoload.php';

//https://stripe.com/docs/payments/checkout/custom-success-page

$database = new Database();
$db = $database->getConnection();
$model = new Model($db);

$session_id = $_GET['session_id'];
//echo $session_id;
//echo '<PRE>';

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
$session = \Stripe\Checkout\Session::retrieve($session_id);
$customer = \Stripe\Customer::retrieve($session->customer);
if(strtolower(trim($session->payment_status.'')) == 'paid'){
  $plan_valid_till = date('Y-m-d 23:59:59', strtotime('+30 day'));
  $model->updateData('users', ' plan_id = ?, plan_valid_till = ?, payment_status = ? where email = ? ',   [2, $plan_valid_till, 'paid', $customer->email.'']);
}
//print_r($customer->email); //$customer->name

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kesher Inc.</title>

    <!-- Primary Meta Tags -->
<meta name="title" content="Autosender">
<meta name="description" content="Autosender">

<!-- Open Graph / Facebook -->
<!-- <meta property="og:type" content="website">
<meta property="og:url" content="https://uideck.com/play/">
<meta property="og:title" content="Play - Free Open Source HTML Bootstrap Template by UIdeck">
<meta property="og:description" content="Play - Free Open Source HTML Bootstrap Template by UIdeck Team">
<meta property="og:image" content="https://uideck.com/wp-content/uploads/2021/09/play-meta-bs.jpg"> -->

<!-- Twitter -->
<!-- <meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://uideck.com/play/">
<meta property="twitter:title" content="Play - Free Open Source HTML Bootstrap Template by UIdeck">
<meta property="twitter:description" content="Play - Free Open Source HTML Bootstrap Template by UIdeck Team">
<meta property="twitter:image" content="https://uideck.com/wp-content/uploads/2021/09/play-meta-bs.jpg">
 -->
    <!--====== Favicon Icon ======-->
    <link
      rel="shortcut icon"
      href="assets/images/favicon.svg"
      type="image/svg"
    />

    <!-- ===== All CSS files ===== -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/lineicons.css" />
    <link rel="stylesheet" href="assets/css/ud-styles.css" />
  </head>
  <body>
    <!-- ====== Header Start ====== -->
    <header class="ud-header">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <nav class="navbar navbar-expand-lg">
              <a class="navbar-brand" href="index.html">
                <img src="assets/images/logo/logo.svg" alt="Logo" />
              </a>
              <button class="navbar-toggler">
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
              </button>

            </nav>
          </div>
        </div>
      </div>
    </header>
    <!-- ====== Header End ====== -->

    <!-- ====== Banner Start ====== -->
    <section class="ud-page-banner">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="ud-banner-content">
                <h1>Payment Success</h1>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ====== Banner End ====== -->
  

    <!-- ====== Login Start ====== -->
    <section class="ud-login">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="ud-login-wrapper">
              <div class="ud-login-logo">
                   <img src="assets/images/logo/logo-2.svg" alt="logo"  />
              </div>
              
                <div class  = "mt-2" >
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Congratulations!!</h4>
                        <p>Subscribed successfully. <hr />
<!--                         <div>Please <a href = "login.php" >click here</a> to login </div>
 -->                        <a href = "./app/dashboard.php">Continue </a>
                        </p>
                     </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ====== Login End ====== -->

    <!-- ====== Footer Start ====== -->
    <footer class="ud-footer wow fadeInUp" data-wow-delay=".15s">
        <div class="shape shape-1">
          <img src="assets/images/footer/shape-1.svg" alt="shape" />
        </div>
        <div class="shape shape-2">
          <img src="assets/images/footer/shape-2.svg" alt="shape" />
        </div>
        <div class="shape shape-3">
          <img src="assets/images/footer/shape-3.svg" alt="shape" />
        </div>
        <div class="ud-footer-bottom">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
                <ul class="ud-footer-bottom-left">
                  <li>
                    <a href="javascript:void(0)">Privacy policy</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Support policy</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Terms of service</a>
                  </li>
                </ul>
              </div>
              <div class="col-md-4">
                <p class="ud-footer-bottom-right">
                  &copy; 2022, Kesher Inc. or its affiliates. All rights reserved.
                  </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <!-- ====== Footer End ====== -->


    <!-- ====== Back To Top Start ====== -->
    <a href="javascript:void(0)" class="back-to-top">
        <i class="lni lni-chevron-up"> </i>
      </a>
      <!-- ====== Back To Top End ====== -->
  
      <!-- ====== All Javascript Files ====== -->
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/main.js"></script>
      <script>
     
      </script>
    </body>
  </html>
  