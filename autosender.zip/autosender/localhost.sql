-- Adminer 4.8.1 MySQL 8.0.27-0ubuntu0.20.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `channels`;
CREATE TABLE `channels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `is_active` int NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `channels` (`id`, `channel_name`, `is_active`, `created_on`) VALUES
(1,	'Email',	1,	'2021-12-28 19:13:23'),
(2,	'SMS',	0,	'2021-12-28 19:13:41');

DROP TABLE IF EXISTS `contacts`;
CREATE TABLE `contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'NULL',
  `start_date` datetime NOT NULL,
  `end_date` datetime DEFAULT NULL,
  `last_sent_on` datetime DEFAULT NULL,
  `send_frequency` varchar(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `template_id` int NOT NULL,
  `proximity` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `closeness` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tags` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_email` (`user_id`,`email`),
  UNIQUE KEY `user_id_phone` (`user_id`,`phone`),
  KEY `user_id` (`user_id`),
  KEY `created_on` (`created_on`),
  KEY `start_date_end_date_status` (`start_date`,`end_date`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `contacts` (`id`, `user_id`, `first_name`, `last_name`, `email`, `phone`, `start_date`, `end_date`, `last_sent_on`, `send_frequency`, `template_id`, `proximity`, `closeness`, `tags`, `status`, `created_on`, `updated_on`) VALUES
(20,	1,	'sdf',	'',	'sarangpatel23@gmaisdf.com',	'90900',	'2022-01-03 16:51:10',	NULL,	'2022-01-02 16:51:10',	'+1 day',	1,	'prixo',	'closnes',	'tags',	1,	'2021-12-28 15:33:12',	'2021-12-28 15:33:12'),
(24,	1,	'sdf',	'',	'sarangpatel23@gmaisdf.com11',	'99',	'2022-01-02 12:00:00',	'2022-01-02 15:00:00',	NULL,	'+7 day',	1,	'prixo',	'closnes',	'tags',	1,	'2021-12-28 15:34:24',	'2021-12-28 15:34:24'),
(26,	1,	'soura h',	'patel',	'abc@fs.com',	'90',	'2022-01-02 17:00:00',	'2022-01-03 17:00:00',	NULL,	'+1 day',	1,	'',	'',	'',	1,	'2021-12-29 12:41:06',	'2021-12-29 12:41:06'),
(30,	1,	'soura h',	'patel',	'abssc@fs.com',	'9090090',	'2022-01-09 16:51:10',	'2022-01-03 18:00:00',	'2022-01-02 16:51:10',	'+7 day',	1,	'',	'',	'',	1,	'2021-12-29 12:41:59',	'2021-12-29 12:41:59'),
(35,	1,	'soura h',	'patel',	'abssc@fs.comxx',	'90909090090',	'2022-01-09 16:51:10',	'2022-01-03 18:00:00',	'2022-01-02 16:51:10',	'+7 day',	1,	'',	'',	'',	1,	'2021-12-29 12:43:18',	'2021-12-29 12:43:18'),
(36,	1,	'soura h',	'patel',	'11@sfs.com',	'9909',	'2022-01-09 16:51:10',	'2022-01-02 19:00:00',	'2022-01-02 16:51:10',	'+7 day',	1,	'',	'',	'',	1,	'2021-12-29 12:45:14',	'2021-12-29 12:45:14'),
(40,	1,	'soura h',	'patel',	'13@sfs.com',	'900000',	'2021-12-11 00:00:00',	'2022-01-02 01:00:00',	NULL,	'+7 day',	1,	'',	'',	'',	1,	'2021-12-29 12:45:22',	'2021-12-29 12:45:22');

DROP TABLE IF EXISTS `message_queue`;
CREATE TABLE `message_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `contact_id` int NOT NULL,
  `send_via` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `send_to` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `template_id` int NOT NULL,
  `meta` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sent` tinyint NOT NULL DEFAULT '0',
  `created_on` datetime NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `status` (`sent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `message_queue` (`id`, `contact_id`, `send_via`, `send_to`, `template_id`, `meta`, `sent`, `created_on`, `updated_on`) VALUES
(77,	20,	'email',	'sarangpatel23@gmaisdf.com',	1,	'{\"first_name\":\"sdf\",\"last_name\":\"\",\"reply_to\":\"sarangpatel23@gmaisdf.com\"}',	1,	'2022-01-02 16:51:10',	'2022-01-02 16:51:10'),
(78,	30,	'email',	'abssc@fs.com',	1,	'{\"first_name\":\"soura h\",\"last_name\":\"patel\",\"reply_to\":\"abssc@fs.com\"}',	1,	'2022-01-02 16:51:10',	'2022-01-02 16:51:10'),
(79,	35,	'email',	'abssc@fs.comxx',	1,	'{\"first_name\":\"soura h\",\"last_name\":\"patel\",\"reply_to\":\"abssc@fs.comxx\"}',	1,	'2022-01-02 16:51:10',	'2022-01-02 16:51:10'),
(80,	36,	'email',	'11@sfs.com',	1,	'{\"first_name\":\"soura h\",\"last_name\":\"patel\",\"reply_to\":\"11@sfs.com\"}',	1,	'2022-01-02 16:51:10',	'2022-01-02 16:51:10');

DROP TABLE IF EXISTS `templates`;
CREATE TABLE `templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `template_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT '',
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('sms','text','email') COLLATE utf8_unicode_ci NOT NULL,
  `is_active` int NOT NULL DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id_is_active` (`user_id`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `templates` (`id`, `user_id`, `template_name`, `subject`, `content`, `type`, `is_active`, `created_on`, `updated_on`) VALUES
(1,	1,	'Email Template',	'Subject',	'MX\r\nXX',	'email',	1,	'2021-12-29 16:28:36',	'2022-01-01 17:04:37'),
(2,	1,	'Templkate 2 emai',	'email subjet',	'emial ocnanct',	'email',	1,	'2021-12-29 16:28:54',	'2021-12-29 16:28:54'),
(5,	1,	'NEWW',	'SuASDFSFD',	'SFDsa\r\nsf\r\n\r\nfsa',	'email',	1,	'2022-01-01 17:17:23',	'2022-01-01 17:17:23'),
(6,	1,	'LASTA',	'last',	'lasfjsaldfa .s,fa smf.s mfsamfsmf.sa.,m',	'email',	1,	'2022-01-01 17:17:35',	'2022-01-01 17:17:35'),
(7,	1,	'xx',	'ss',	'xsd\r\ns\r\nfsfd',	'email',	1,	'2022-01-01 17:32:12',	'2022-01-01 17:32:12'),
(8,	1,	'x',	NULL,	's\r\ns\r\ns',	'email',	1,	'2022-01-01 17:33:03',	'2022-01-01 17:33:03');

DROP TABLE IF EXISTS `user_channels`;
CREATE TABLE `user_channels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `contact_id` int NOT NULL,
  `channel_id` int NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_id_contact_id` (`user_id`,`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `user_channels` (`id`, `user_id`, `contact_id`, `channel_id`, `created_on`) VALUES
(1,	1,	20,	1,	'2021-12-28 21:20:07'),
(2,	1,	24,	1,	'2021-12-28 21:20:07'),
(3,	1,	26,	1,	'2021-12-29 13:39:46'),
(4,	1,	30,	1,	'2021-12-29 13:55:56'),
(5,	1,	35,	1,	'2021-12-29 13:56:12'),
(6,	1,	36,	1,	'2021-12-29 13:56:23'),
(7,	1,	40,	1,	'2021-12-29 13:56:28'),
(8,	1,	58,	1,	'2021-12-29 14:00:28'),
(9,	1,	60,	1,	'2021-12-29 14:00:58'),
(10,	1,	64,	1,	'2021-12-29 14:02:08'),
(11,	1,	67,	1,	'2021-12-29 14:03:02'),
(12,	1,	68,	1,	'2021-12-29 14:04:06'),
(13,	1,	70,	1,	'2021-12-29 14:04:28'),
(14,	1,	72,	1,	'2021-12-30 16:44:05'),
(15,	1,	73,	1,	'2021-12-30 19:30:57'),
(16,	1,	76,	1,	'2022-01-01 09:37:18'),
(17,	1,	77,	1,	'2022-01-01 09:41:14'),
(18,	1,	78,	1,	'2022-01-01 09:41:48'),
(19,	1,	79,	1,	'2022-01-01 09:59:59'),
(20,	1,	80,	1,	'2022-01-01 10:00:14'),
(21,	1,	81,	1,	'2022-01-01 10:00:27'),
(22,	1,	82,	1,	'2022-01-01 10:04:42'),
(23,	1,	83,	1,	'2022-01-01 10:17:15'),
(24,	1,	84,	1,	'2022-01-01 10:18:25'),
(25,	1,	85,	1,	'2022-01-01 10:41:19'),
(26,	1,	87,	1,	'2022-01-01 10:42:13'),
(27,	1,	88,	1,	'2022-01-01 10:47:32'),
(28,	1,	89,	1,	'2022-01-01 17:19:28'),
(29,	1,	90,	1,	'2022-01-02 11:03:40');

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `full_name` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `plan` enum('free','premium') CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'free',
  `user_type` enum('user','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'user',
  `status` int DEFAULT '1',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `email_password_status` (`email`,`password`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `users` (`id`, `email`, `password`, `full_name`, `plan`, `user_type`, `status`, `created_on`, `updated_on`) VALUES
(1,	'sarangpatel23@gmail.com',	'ceb6c970658f31504a901b89dcd3e461',	'Sarang Patel',	'free',	'user',	1,	'2021-12-28 17:59:14',	'2021-12-28 17:59:14');

-- 2022-01-02 16:59:03
