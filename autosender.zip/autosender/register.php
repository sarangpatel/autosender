<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kesher Inc.</title>

    <!-- Primary Meta Tags -->
<meta name="title" content="Autosender">
<meta name="description" content="Autosender">

<!-- Open Graph / Facebook -->
<!-- <meta property="og:type" content="website">
<meta property="og:url" content="https://uideck.com/play/">
<meta property="og:title" content="Play - Free Open Source HTML Bootstrap Template by UIdeck">
<meta property="og:description" content="Play - Free Open Source HTML Bootstrap Template by UIdeck Team">
<meta property="og:image" content="https://uideck.com/wp-content/uploads/2021/09/play-meta-bs.jpg"> -->

<!-- Twitter -->
<!-- <meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://uideck.com/play/">
<meta property="twitter:title" content="Play - Free Open Source HTML Bootstrap Template by UIdeck">
<meta property="twitter:description" content="Play - Free Open Source HTML Bootstrap Template by UIdeck Team">
<meta property="twitter:image" content="https://uideck.com/wp-content/uploads/2021/09/play-meta-bs.jpg">
 -->
    <!--====== Favicon Icon ======-->
    <link
      rel="shortcut icon"
      href="assets/images/favicon.svg"
      type="image/svg"
    />

    <!-- ===== All CSS files ===== -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/css/animate.css" />
    <link rel="stylesheet" href="assets/css/lineicons.css" />
    <link rel="stylesheet" href="assets/css/ud-styles.css" />
    <style>
     @media (max-width: 400px) {
      .navbar-toggler{
        display: none;
        
      }
    }
   </style>
  </head>
  <body>
    <!-- ====== Header Start ====== -->
    <header class="ud-header">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <nav class="navbar navbar-expand-lg">
              <a class="navbar-brand" href="index.html">
                <img src="assets/images/logo/logo.svg" alt="Logo" />
              </a>
              <button class="navbar-toggler">
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
                <span class="toggler-icon"> </span>
              </button>

              <!-- <div class="navbar-collapse">
                <ul id="nav" class="navbar-nav mx-auto">
                  <li class="nav-item">
                    <a class="ud-menu-scroll" href="index.html#home">Home</a>
                  </li>

                  <li class="nav-item">
                    <a class="ud-menu-scroll" href="index.html#about">About</a>
                  </li>
                </ul>
              </div> -->


            </nav>
          </div>
        </div>
      </div>
    </header>
    <!-- ====== Header End ====== -->

    <!-- ====== Banner Start ====== -->
    <section class="ud-page-banner">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="ud-banner-content">
                <h1>Register</h1>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ====== Banner End ====== -->
  

    <!-- ====== Login Start ====== -->
    <section class="ud-login">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="ud-login-wrapper">
          <!--     <div class="ud-login-logo">
                <img src="assets/images/logo/logo-2.svg" alt="logo" />
              </div> -->
              <form class="ud-login-form" action = "./app/register.php" method = "POST">
                <div class = "login-err-msg"><?php echo isset($_SESSION['autosender']['err_msg'])? $_SESSION['autosender']['err_msg']: '' ; ?></div>

                <div class="ud-form-group">
                    <input
                      type="text"
                      name="full_name"
                      placeholder="Enter your name" required
                    />
                  </div>
  
                <div class="ud-form-group">
                  <input
                    type="email" required
                    name="email"
                    placeholder="Email/username"
                  />
                </div>
                <div class="ud-form-group">
                  <input
                    type="password"
                    name="password" required
                    placeholder="Type password"
                  />
                </div>
                <div class="ud-form-group">
                        <select name = "plan_id" class = "form-control" required>
                            <option value  = "">Select Plan</option>
                            <option value  = "1">Free ( only 3 contacts)</option>
                            <option value  = "2">Paid ( unlimited contacts )</option>
                        </select>
                </div>
  
                <div class="ud-form-group">
                  <button type="submit" class="ud-main-btn w-100">Register</button>
                </div>
              </form>
              <p class="signup-option">
                Already registered? <a href="login.php"> Login </a>
              </p>

              <!--<div class="ud-socials-connect">
                <p>Connect With</p>

                <ul>
                  <li>
                    <a href="javascript:void(0)" class="facebook">
                      <i class="lni lni-facebook-filled"></i>
                    </a>
                  </li>
                  <li>
                    <a href="javascript:void(0)" class="google">
                      <i class="lni lni-google"></i>
                    </a>
                  </li>
                </ul>
              </div>-->

              <!--<a class="forget-pass" href="javascript:void(0)">
                Forget Password?
              </a> -->
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- ====== Login End ====== -->

    <!-- ====== Footer Start ====== -->
    <footer class="ud-footer wow fadeInUp" data-wow-delay=".15s">
        <div class="shape shape-1">
          <img src="assets/images/footer/shape-1.svg" alt="shape" />
        </div>
        <div class="shape shape-2">
          <img src="assets/images/footer/shape-2.svg" alt="shape" />
        </div>
        <div class="shape shape-3">
          <img src="assets/images/footer/shape-3.svg" alt="shape" />
        </div>
        <div class="ud-footer-bottom">
          <div class="container">
            <div class="row">
              <div class="col-md-8">
                <ul class="ud-footer-bottom-left">
                  <li>
                    <a href="javascript:void(0)">Privacy policy</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Support policy</a>
                  </li>
                  <li>
                    <a href="javascript:void(0)">Terms of service</a>
                  </li>
                </ul>
              </div>
              <div class="col-md-4">
                <p class="ud-footer-bottom-right">
                  &copy; 2022, Kesher Inc. or its affiliates. All rights reserved.
                  </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
      <!-- ====== Footer End ====== -->


    <!-- ====== Back To Top Start ====== -->
    <a href="javascript:void(0)" class="back-to-top">
        <i class="lni lni-chevron-up"> </i>
      </a>
      <!-- ====== Back To Top End ====== -->
  
      <!-- ====== All Javascript Files ====== -->
      <script src="assets/js/bootstrap.bundle.min.js"></script>
      <script src="assets/js/wow.min.js"></script>
      <script src="assets/js/main.js"></script>
      <script>
     
      </script>
    </body>
  </html>
  